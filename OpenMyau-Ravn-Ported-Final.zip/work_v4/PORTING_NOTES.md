# OpenMyau + Ravn module port

This tree is based on OpenMyau-Plus-1.6-1 and contains the Ravn-derived module ports requested for:
- AimAssist combo aim behavior
- AimSmooth
- AutoStyle
- Bridge Assist
- Legit Telly

The OpenMyau event/property architecture is retained; Ravn's Guava event bus and old Gradle project are not copied into this tree.

## Build

- Minecraft: 1.8.9
- Forge: 11.15.1.2318
- Java: 8
- Gradle wrapper: 8.8
- Mixin: 0.8.5 for compile, annotation processing, and packaged runtime

Run:

```bash
./gradlew clean build --no-daemon
```

The resulting jars are under `build/libs/`.

## GitHub ZIP workflow

A workflow template is included under `WORKFLOWS/build-from-zip.yml` and also copied to `.github/workflows/build-from-zip.yml`.
