package myau.module.modules.autostyle;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class FlickEngine {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private FlickTrajectory trajectory;
    private long flickStart = 0L;
    private boolean flicking = false;
    private int spinChainIndex = 0;
    private int queued360 = 0;
    private float smoothedTargetYaw;
    private float smoothedTargetPitch;
    private boolean hasSmoothedTarget;

    public boolean isFlicking() {
        return flicking;
    }

    public void reset() {
        trajectory = null;
        flicking = false;
        spinChainIndex = 0;
        queued360 = 0;
        hasSmoothedTarget = false;
    }

    public void queue360() {
        queued360 = Math.min(queued360 + 1, 4);
    }

    public void startFlick(EntityPlayer target, double intensity, double pitchAmount,
                           int styleHint, boolean spin, boolean exactReturn) {
        startFlick(target, intensity, pitchAmount, styleHint, spin, exactReturn, 1.0D);
    }

    public void startFlick(EntityPlayer target, double intensity, double pitchAmount,
                           int styleHint, boolean spin, boolean exactReturn, double speedMultiplier) {
        if (mc.thePlayer == null || target == null || !MovementAnalyzer.isPlayerMoving()) return;

        hasSmoothedTarget = true;
        smoothedTargetYaw = getDesiredYaw(target);
        smoothedTargetPitch = getDesiredPitch(target);

        final float startYaw = mc.thePlayer.rotationYaw;
        final float startPitch = mc.thePlayer.rotationPitch;
        double speed = Math.max(0.60D, Math.min(1.30D, 0.55D + (speedMultiplier * 0.45D));

        if (spin) {
            boolean clockwise = (spinChainIndex & 1) == 0;
            spinChainIndex++;
            create360(startYaw, startPitch, pitchAmount, clockwise, exactReturn, speed);
        } else {
            int selectedStyle = selectStyle(styleHint, target);
            float desiredYaw = getDesiredYaw(target);
            float desiredPitch = getDesiredPitch(target);
            createStyle(startYaw, startPitch, desiredYaw, desiredPitch,
                    intensity, pitchAmount, target, selectedStyle, speed);
        }

        flickStart = System.nanoTime();
        flicking = trajectory != null;
    }

    private int selectStyle(int configuredStyle, EntityPlayer target) {
        if (configuredStyle != 0) return configuredStyle;

        float relative = Math.abs(MovementAnalyzer.getRelativeAngleToTarget(target));
        MovementAnalyzer.StrafeDirection strafe = MovementAnalyzer.getPlayerStrafe();
        double speed = MovementAnalyzer.getHorizontalVelocity();

        if (MovementAnalyzer.isPlayerStrafing()) {
            if (relative > 115.0F) return 4;
            return speed > 0.08D ? 1 : 5;
        }
        if (strafe == MovementAnalyzer.StrafeDirection.BACKWARD) return 2;
        if (strafe == MovementAnalyzer.StrafeDirection.FORWARD && relative < 45.0F) return 3;
        if (relative > 70.0F) return 4;
        return 5;
    }

    private long scale(long base, double speed) {
        return Math.max(6_000_000L, (long) (base / speed));
    }

    private void create360(float startYaw, float startPitch, double pitchAmount,
                           boolean clockwise, boolean exactReturn, double speed) {
        float sign = clockwise ? 1.0F : -1.0F;
        float peakYaw = startYaw + sign * 360.0F;
        float peakPitch = Rotation.clampPitch(startPitch + sign * (float) Math.min(3.0D, pitchAmount * 0.10D));

        long away = scale(260_000_000L, speed);
        long hold = scale(12_000_000L, speed);
        long back = scale(280_000_000L, speed);
        trajectory = new FlickTrajectory(
                startYaw, startPitch,
                peakYaw, peakPitch,
                exactReturn ? startYaw : peakYaw,
                exactReturn ? startPitch : peakPitch,
                away, hold, back,
                FlickTrajectory.Style.SPIN
        );
    }

    private void createStyle(float startYaw, float startPitch, float desiredYaw,
                             float desiredPitch, double intensity, double pitchAmount,
                             EntityPlayer target, int style, double speed) {
        double distance = mc.thePlayer.getDistanceToEntity(target);
        double distanceFactor = Math.max(0.60D, Math.min(1.0D, distance / 3.2D));
        double amplitude = Math.min(34.0D, (9.0D + intensity * 0.24D) * distanceFactor);

        float error = Rotation.angleDiff(startYaw, desiredYaw);
        float side = error >= 0.0F ? -1.0F : 1.0F;
        float yawOffset;
        float pitchOffset;

        switch (style) {
            case 1:
                yawOffset = side * (float) amplitude;
                pitchOffset = side * (float) Math.min(6.0D, pitchAmount * 0.30D);
                break;
            case 2:
                yawOffset = side * (float) (amplitude * 0.55D);
                pitchOffset = Math.abs((float) Math.min(11.0D, pitchAmount));
                break;
            case 3:
                yawOffset = -side * (float) (amplitude * 0.55D);
                pitchOffset = -Math.abs((float) Math.min(11.0D, pitchAmount));
                break;
            case 4:
                yawOffset = side * (float) (amplitude * 0.82D);
                pitchOffset = side * (float) Math.min(9.0D, pitchAmount * 0.70D);
                break;
            default:
                yawOffset = side * (float) (amplitude * 0.65D);
                pitchOffset = side * (float) Math.min(6.0D, pitchAmount * 0.38D);
                break;
        }

        float peakYaw = startYaw + yawOffset;
        float peakPitch = Rotation.clampPitch(startPitch + pitchOffset);

        long away = scale(155_000_000L, speed);
        long hold = scale(12_000_000L, speed);
        long toTarget = scale(150_000_000L, speed);
        long toStart = scale(165_000_000L, speed);

        // The first return phase tracks the enemy's CURRENT position rather than
        // a stale rotation captured at the start. The second phase returns to the
        // exact starting rotation, eliminating the common "miss on the way back"
        // caused by target movement and static-angle drift.
        trajectory = new FlickTrajectory(
                startYaw, startPitch,
                peakYaw, peakPitch,
                away, hold, toTarget, toStart,
                FlickTrajectory.Style.NORMAL, target
        );
    }

    public Rotation evaluate() {
        if (!flicking || trajectory == null) return null;

        long elapsed = Math.max(0L, System.nanoTime() - flickStart);
        float dynamicYaw = mc.thePlayer.rotationYaw;
        float dynamicPitch = mc.thePlayer.rotationPitch;
        if (trajectory.getDynamicTarget() != null) {
            float rawYaw = getDesiredYaw(trajectory.getDynamicTarget());
            float rawPitch = getDesiredPitch(trajectory.getDynamicTarget());

            if (!hasSmoothedTarget) {
                smoothedTargetYaw = rawYaw;
                smoothedTargetPitch = rawPitch;
                hasSmoothedTarget = true;
            }

            float yawStep = Math.max(-5.0F, Math.min(5.0F,
                    Rotation.angleDiff(smoothedTargetYaw, rawYaw)));
            float pitchStep = Math.max(-3.0F, Math.min(3.0F, rawPitch - smoothedTargetPitch));
            smoothedTargetYaw += yawStep;
            smoothedTargetPitch = Rotation.clampPitch(smoothedTargetPitch + pitchStep);

            dynamicYaw = smoothedTargetYaw;
            dynamicPitch = smoothedTargetPitch;
        }
        Rotation rotation = trajectory.evaluate(elapsed, dynamicYaw, dynamicPitch);

        if (trajectory.isComplete(elapsed)) {
            flicking = false;
            trajectory = null;

            if (queued360 > 0 && mc.thePlayer != null && MovementAnalyzer.isPlayerMoving()) {
                queued360--;
                boolean clockwise = (spinChainIndex & 1) == 0;
                spinChainIndex++;
                create360(mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, 3.0D, clockwise, true, 1.0D);
                flickStart = System.nanoTime();
                flicking = trajectory != null;
            } else if (queued360 == 0) {
                spinChainIndex = 0;
            }
        }

        return rotation;
    }

    public long getTrajectoryDurationNanos() {
        return trajectory != null ? trajectory.getTotalNanos() : 0L;
    }

    private float getDesiredYaw(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    private float getDesiredPitch(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = target.posY + target.getEyeHeight() * 0.5D - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return Rotation.clampPitch((float) (-Math.toDegrees(Math.atan2(dy, dist))));
    }
}
