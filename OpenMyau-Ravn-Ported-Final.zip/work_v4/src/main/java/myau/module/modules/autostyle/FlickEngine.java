package myau.module.modules.autostyle;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Camera-style flick engine. The trajectory is always anchored to the exact
 * rotation captured when the flick starts, so every style returns to that
 * exact camera position instead of leaving rotation drift behind.
 */
public class FlickEngine {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private FlickTrajectory trajectory;
    private long flickStart = 0L;
    private boolean flicking = false;
    private int chainIndex = 0;

    public boolean isFlicking() { return flicking; }

    public void reset() {
        trajectory = null;
        flicking = false;
        chainIndex = 0;
    }

    public void startFlick(
        EntityPlayer target,
        double intensity,
        double pitchAmount,
        int styleHint,
        boolean combo360
    ) {
        if (mc.thePlayer == null || target == null || !MovementAnalyzer.isPlayerMoving()) return;

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;
        float targetYaw = getDesiredYaw(target);
        float targetPitch = getDesiredPitch(target);

        if (combo360) {
            // Alternate direction every 360 in the chain: normal, reverse, normal...
            boolean clockwise = (chainIndex & 1) == 0;
            chainIndex++;
            create360Flick(curYaw, curPitch, pitchAmount, clockwise);
        } else {
            // Situation-aware style selection.
            int style = selectStyle(styleHint, target);
            createStyleFlick(curYaw, curPitch, targetYaw, targetPitch,
                    intensity, pitchAmount, target, style);
            chainIndex = 0;
        }

        flickStart = System.nanoTime();
        flicking = true;
    }

    private int selectStyle(int configuredStyle, EntityPlayer target) {
        // 0=AUTO, 1=SIDEWAYS, 2=LOOK-DOWN, 3=LOOK-UP, 4=DIAGONAL, 5=CLEAN
        if (configuredStyle != 0) return configuredStyle;

        float relative = Math.abs(MovementAnalyzer.getRelativeAngleToTarget(target));
        MovementAnalyzer.StrafeDirection strafe = MovementAnalyzer.getPlayerStrafe();

        if (MovementAnalyzer.isPlayerStrafing()) {
            if (relative > 110.0F) return 4; // diagonal when target is on the far side
            return 1; // sideways while strafing
        }
        if (strafe == MovementAnalyzer.StrafeDirection.BACKWARD) return 2;
        if (strafe == MovementAnalyzer.StrafeDirection.FORWARD && relative < 35.0F) return 3;
        return 5;
    }

    private void create360Flick(
        float startYaw, float startPitch,
        double pitchAmount,
        boolean clockwise
    ) {
        float sign = clockwise ? 1.0F : -1.0F;
        // Full turn plus a small controlled overshoot, never a random 280-360 partial turn.
        float spinAmount = 360.0F + (float) (2.0 + Math.random() * 6.0);
        float peakYaw = startYaw + sign * spinAmount;
        float peakPitch = Rotation.clampPitch(startPitch + sign * (float) Math.min(4.0, pitchAmount * 0.12));

        long awayNs = 90_000_000L + (long) (Math.random() * 20_000_000L);
        long holdNs = 5_000_000L + (long) (Math.random() * 8_000_000L);
        long returnNs = 95_000_000L + (long) (Math.random() * 25_000_000L);

        // End at the exact start rotation.
        trajectory = new FlickTrajectory(
                startYaw, startPitch,
                peakYaw, peakPitch,
                startYaw, startPitch,
                awayNs, holdNs, returnNs,
                FlickTrajectory.Style.SPIN
        );
    }

    private void createStyleFlick(
        float startYaw, float startPitch,
        float desiredYaw, float desiredPitch,
        double intensity, double pitchAmount,
        EntityPlayer target, int style
    ) {
        double distance = mc.thePlayer.getDistanceToEntity(target);
        double distFactor = Math.max(0.55, Math.min(1.0, distance / 3.2));
        double base = 11.0 + intensity * 0.22;
        double amplitude = Math.min(34.0, base * distFactor);

        float yawSign = Rotation.angleDiff(startYaw, desiredYaw) >= 0.0F ? -1.0F : 1.0F;
        float pitchSign = Rotation.angleDiff(startYaw, desiredYaw) >= 0.0F ? 1.0F : -1.0F;

        float yawOffset = 0.0F;
        float pitchOffset = 0.0F;
        switch (style) {
            case 1: // sideways
                yawOffset = yawSign * (float) amplitude;
                pitchOffset = pitchSign * (float) Math.min(7.0, pitchAmount * 0.35);
                break;
            case 2: // down
                yawOffset = yawSign * (float) (amplitude * 0.55);
                pitchOffset = Math.abs((float) Math.min(12.0, pitchAmount)) * 0.9F;
                break;
            case 3: // up
                yawOffset = -yawSign * (float) (amplitude * 0.55);
                pitchOffset = -Math.abs((float) Math.min(12.0, pitchAmount)) * 0.9F;
                break;
            case 4: // diagonal
                yawOffset = yawSign * (float) (amplitude * 0.82);
                pitchOffset = pitchSign * (float) Math.min(10.0, pitchAmount * 0.75);
                break;
            default: // clean
                yawOffset = yawSign * (float) (amplitude * 0.72);
                pitchOffset = pitchSign * (float) Math.min(7.0, pitchAmount * 0.45);
                break;
        }

        float peakYaw = startYaw + yawOffset;
        float peakPitch = Rotation.clampPitch(startPitch + pitchOffset);

        long awayNs = 55_000_000L + (long) (Math.random() * 20_000_000L);
        long holdNs = 8_000_000L + (long) (Math.random() * 12_000_000L);
        long returnNs = 105_000_000L + (long) (Math.random() * 35_000_000L);

        // Crucially, the end is the captured start rotation, not target rotation.
        trajectory = new FlickTrajectory(
                startYaw, startPitch,
                peakYaw, peakPitch,
                startYaw, startPitch,
                awayNs, holdNs, returnNs,
                FlickTrajectory.Style.NORMAL
        );
    }

    public Rotation evaluate() {
        if (!flicking || trajectory == null) return null;

        long elapsed = System.nanoTime() - flickStart;
        Rotation rot = trajectory.evaluate(elapsed);

        if (trajectory.isComplete(elapsed)) {
            flicking = false;
            trajectory = null;
        }

        return rot;
    }

    public long getTrajectoryDurationNanos() {
        return trajectory != null ? trajectory.getTotalNanos() : 0L;
    }

    private float getDesiredYaw(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    private float getDesiredPitch(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * 0.5) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return Rotation.clampPitch((float) (-Math.toDegrees(Math.atan2(dy, dist))));
    }
}
