package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import myau.util.KeyBindUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;

import java.util.Locale;
import org.lwjgl.input.Mouse;

public class FastPlace extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private long nextClickTime = 0L;
    private long lastCpsUpdate = 0L;
    private long startHoldingTime = 0L;
    private double currentTargetCps = 0.0D;
    private boolean butterflySecondClick = false;
    private int slowClicksRemaining = 0;

    public final ModeProperty mode = new ModeProperty(
            "mode", 2, new String[]{"NORMAL", "JITTER", "BUTTERFLY", "DRAG"}
    );
    public final IntProperty minCPS = new IntProperty("min-cps", 25, 1, 50);
    public final IntProperty maxCPS = new IntProperty("max-cps", 30, 1, 50);
    public final IntProperty initialDelay = new IntProperty("initial-delay", 120, 5, 1000);
    public final BooleanProperty onlyHolding = new BooleanProperty("only-holding", true);
    public final BooleanProperty blocksOnly = new BooleanProperty("blocks-only", true);
    public final BooleanProperty blacklistObsidian = new BooleanProperty("blacklist-obsidian", true);
    public final BooleanProperty legit = new BooleanProperty("legit", false);

    public FastPlace() {
        super("FastPlace", false);
    }

    @Override
    public void onEnabled() {
        resetState();
    }

    @Override
    public void onDisabled() {
        resetState();
    }

    private void resetState() {
        nextClickTime = 0L;
        lastCpsUpdate = 0L;
        startHoldingTime = 0L;
        butterflySecondClick = false;
        slowClicksRemaining = 0;
        currentTargetCps = 0.0D;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE || mc.thePlayer == null || mc.theWorld == null) {
            return;
        }

        boolean holding = Mouse.isButtonDown(1);

        if (onlyHolding.getValue() && !holding) {
            resetState();
            return;
        }

        if (!onlyHolding.getValue()) {
            holding = true;
        }

        if (!canUseHeldItem()) {
            resetState();
            return;
        }

        long now = System.currentTimeMillis();

        if (startHoldingTime == 0L) {
            startHoldingTime = now;
            nextClickTime = now + initialDelay.getValue() + calculateDelay();
            return;
        }

        // Match FastPlacePlus scheduling: allow multiple due clicks on a slow tick
        // instead of artificially limiting the module to one click every 50 ms.
        int safety = 0;
        while (now >= nextClickTime && safety++ < 4) {
            clickOnce();

            if (mode.getValue() == 2) {
                if (butterflySecondClick) {
                    butterflySecondClick = false;
                    nextClickTime = now + (legit.getValue() ? randomInt(10, 25) : 20);
                } else {
                    butterflySecondClick = true;
                    nextClickTime = now + calculateDelay();
                }
            } else {
                nextClickTime = now + calculateDelay();
            }
        }
    }

    private boolean canUseHeldItem() {
        ItemStack held = mc.thePlayer.getHeldItem();

        if (blocksOnly.getValue()) {
            if (held == null || !(held.getItem() instanceof ItemBlock)) {
                return false;
            }
        }

        if (held == null) {
            return false;
        }

        if (held.getItem() instanceof ItemFishingRod) {
            return false;
        }

        if (blacklistObsidian.getValue()) {
            if (held.getItem() instanceof ItemBlock
                    && ((ItemBlock) held.getItem()).getBlock() instanceof BlockObsidian) {
                return false;
            }

            MovingObjectPosition mop = mc.objectMouseOver;
            if (mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                Block block = mc.theWorld.getBlockState(mop.getBlockPos()).getBlock();
                if (block instanceof BlockObsidian) {
                    return false;
                }
            }
        }

        return true;
    }

    private void clickOnce() {
        int key = mc.gameSettings.keyBindUseItem.getKeyCode();
        KeyBindUtil.setKeyBindState(key, false);
        KeyBindUtil.pressKeyOnce(key);
    }

    private long calculateDelay() {
        long now = System.currentTimeMillis();
        int modeValue = mode.getValue();
        boolean isLegit = legit.getValue();

        if (currentTargetCps <= 0.0D || (isLegit && now - lastCpsUpdate > randomInt(800, 2000))) {
            double min = minCPS.getValue();
            double max = maxCPS.getValue();

            if (min > max) {
                double temp = min;
                min = max;
                max = temp;
            }

            currentTargetCps = min + Math.random() * (max - min);
            lastCpsUpdate = now;
        }

        long baseDelay = Math.max(1L, (long) (1000.0D / currentTargetCps));

        if (!isLegit) {
            return baseDelay;
        }

        if (modeValue == 3) {
            return randomInt(33, 45);
        }

        long extraDelay = 0L;

        if (slowClicksRemaining > 0) {
            extraDelay = randomInt(20, 50);
            slowClicksRemaining--;
        } else {
            double slowChance = modeValue == 1 ? 0.04D : 0.06D;
            if (Math.random() < slowChance) {
                slowClicksRemaining = randomInt(1, 3);
            }
        }

        long delay = baseDelay + extraDelay;

        if (modeValue == 1) {
            delay += randomInt(-2, 6);
        } else {
            delay += randomInt(-5, 12);
        }

        return Math.max(34L, delay);
    }

    private int randomInt(int min, int max) {
        if (max <= min) return min;
        return min + (int) (Math.random() * (max - min + 1));
    }

    @Override
    public void verifyValue(String name) {
        if ("min-cps".equals(name) && minCPS.getValue() > maxCPS.getValue()) {
            maxCPS.setValue(minCPS.getValue());
        } else if ("max-cps".equals(name) && maxCPS.getValue() < minCPS.getValue()) {
            minCPS.setValue(maxCPS.getValue());
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{String.format(Locale.US, "%d-%d", minCPS.getValue(), maxCPS.getValue())};
    }
}
