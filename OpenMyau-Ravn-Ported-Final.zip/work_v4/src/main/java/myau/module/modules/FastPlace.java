package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.mixin.IAccessorMinecraft;
import myau.module.Module;
import myau.util.BlockUtil;
import myau.util.RotationUtil;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import myau.util.KeyBindUtil;
import myau.util.RandomUtil;
import org.lwjgl.input.Mouse;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class FastPlace extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final DecimalFormat df = new DecimalFormat("0.0#", new DecimalFormatSymbols(Locale.US));
    private long nextPlaceAt = 0L;
    private long lastCpsUpdate = 0L;
    private double currentTargetCps = 0.0D;
    private boolean butterflySecondClick;
    public final ModeProperty mode = new ModeProperty("mode", 0, new String[]{"NORMAL", "JITTER", "BUTTERFLY", "DRAG"});
    public final IntProperty minCPS = new IntProperty("min-cps", 18, 1, 50);
    public final IntProperty maxCPS = new IntProperty("max-cps", 22, 1, 50);
    public final IntProperty initialDelay = new IntProperty("initial-delay", 80, 5, 1000);
    public final BooleanProperty onlyHolding = new BooleanProperty("only-holding", true);
    public final BooleanProperty blocksOnly = new BooleanProperty("blocks-only", true);
    public final BooleanProperty placeFix = new BooleanProperty("place-fix", true);
    public final BooleanProperty skipObsidian = new BooleanProperty("blacklist-obsidian", true);
    public final BooleanProperty skipInteractable = new BooleanProperty("skip-interactable", true);
    public final BooleanProperty legit = new BooleanProperty("legit", false);

    private boolean canPlace() {
        ItemStack stack = mc.thePlayer.getHeldItem();
        if (stack != null) {
            Item item = stack.getItem();
            if (item instanceof ItemFishingRod) {
                return false;
            }
            if (item instanceof ItemBlock) {
                Block block = ((ItemBlock) item).getBlock();
                if (skipObsidian.getValue() && block instanceof BlockObsidian) {
                    return false;
                }
                if (skipInteractable.getValue() && BlockUtil.isInteractable(block)) {
                    return false;
                }
                if (!(Boolean) this.placeFix.getValue()) {
                    return true;
                }
                MovingObjectPosition mop = RotationUtil.rayTrace(
                        mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, mc.playerController.getBlockReachDistance(), 1.0F
                );
                return mop != null
                        && mop.typeOfHit == MovingObjectType.BLOCK
                        && ((ItemBlock) item).canPlaceBlockOnSide(mc.theWorld, mop.getBlockPos(), mop.sideHit, mc.thePlayer, stack);
            }
        }
        return !(Boolean) this.blocksOnly.getValue();
    }

    public FastPlace() {
        super("FastPlace", false);
    }

    private long calculateDelay() {
        long now = System.currentTimeMillis();
        int min = Math.min(this.minCPS.getValue(), this.maxCPS.getValue());
        int max = Math.max(this.minCPS.getValue(), this.maxCPS.getValue());
        if (this.currentTargetCps == 0.0D || now - this.lastCpsUpdate > 1200L) {
            this.currentTargetCps = RandomUtil.nextDouble(min, max);
            this.lastCpsUpdate = now;
        }
        long base = Math.max(20L, (long) (1000.0D / Math.max(1.0D, this.currentTargetCps)));
        if (!this.legit.getValue()) return base;
        if (this.mode.getValue() == 3) return RandomUtil.nextLong(33L, 45L);
        long variance = this.mode.getValue() == 1 ? RandomUtil.nextLong(-2L, 6L) : RandomUtil.nextLong(-5L, 12L);
        return Math.max(20L, base + variance);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE || mc.thePlayer == null) return;

        boolean holding = mc.gameSettings.keyBindUseItem.isKeyDown() || Mouse.isButtonDown(1);
        if (this.onlyHolding.getValue() && !holding) {
            this.nextPlaceAt = 0L;
            this.butterflySecondClick = false;
            return;
        }
        if (!this.onlyHolding.getValue()) holding = true;
        if (!holding || !this.canPlace()) return;

        long now = System.currentTimeMillis();
        if (this.nextPlaceAt == 0L) {
            this.nextPlaceAt = now + this.initialDelay.getValue() + this.calculateDelay();
        }

        // Keep vanilla's placement cooldown at zero whenever our cadence allows the
        // next action. This retains Minecraft 1.8.9's normal placement validation.
        if (now >= this.nextPlaceAt) {
            ((IAccessorMinecraft) mc).setRightClickDelayTimer(0);
            int m = this.mode.getValue();
            if (m == 2) {
                KeyBindUtil.pressKeyOnce(mc.gameSettings.keyBindUseItem.getKeyCode());
                if (this.butterflySecondClick) {
                    this.nextPlaceAt = now + (this.legit.getValue() ? RandomUtil.nextLong(10L, 25L) : 20L);
                } else {
                    this.nextPlaceAt = now + this.calculateDelay();
                }
                this.butterflySecondClick = !this.butterflySecondClick;
            } else {
                KeyBindUtil.pressKeyOnce(mc.gameSettings.keyBindUseItem.getKeyCode());
                this.nextPlaceAt = now + this.calculateDelay();
            }
        }

        if (((IAccessorMinecraft) mc).getRightClickDelayTimer() > 1 && now >= this.nextPlaceAt) {
            ((IAccessorMinecraft) mc).setRightClickDelayTimer(0);
        }
    }

    @Override
    public void onDisabled() {
        this.nextPlaceAt = 0L;
        this.currentTargetCps = 0.0D;
        this.butterflySecondClick = false;
    }

    @Override
    public String[] getSuffix() {
        int min = Math.min(this.minCPS.getValue(), this.maxCPS.getValue());
        int max = Math.max(this.minCPS.getValue(), this.maxCPS.getValue());
        return new String[]{min == max ? Integer.toString(min) : min + "-" + max};
    }
}
