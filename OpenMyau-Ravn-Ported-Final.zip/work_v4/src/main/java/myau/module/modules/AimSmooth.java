package myau.module.modules;

import myau.Myau;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import net.minecraft.client.Minecraft;

public class AimSmooth extends Module {
    public final IntProperty smoothing = new IntProperty("smoothing", 7, 0, 100);
    public final BooleanProperty separateY = new BooleanProperty("separate-y", false);
    public final IntProperty verticalSmoothing = new IntProperty("vertical-smoothing", 7, 0, 100);

    private static double filteredX, filteredY, residualX, residualY;
    private static long lastTimeNanos = -1L;
    private static final int[] RESULT = new int[2];

    public AimSmooth() { super("AimSmooth", false); }

    @Override public void onEnabled() { reset(); }
    @Override public void onDisabled() { reset(); }

    public static int[] onMouseDelta(int rawX, int rawY) {
        AimSmooth module = (AimSmooth) Myau.moduleManager.getModule(AimSmooth.class);
        if (module == null || !module.isEnabled()) { RESULT[0] = rawX; RESULT[1] = rawY; return RESULT; }
        if (Minecraft.getMinecraft().currentScreen != null) { reset(); RESULT[0] = rawX; RESULT[1] = rawY; return RESULT; }
        long now = System.nanoTime();
        double dt = lastTimeNanos < 0L ? 0.016D : (now-lastTimeNanos)*1.0E-9D;
        lastTimeNanos = now;
        dt = Math.max(0.001D, Math.min(0.1D, dt));
        double hs = module.smoothing.getValue()/100.0D;
        double ha = 1.0D - Math.exp(-dt/(hs*0.3D+0.001D));
        filteredX += (rawX-filteredX)*ha;
        double vs = module.separateY.getValue() ? module.verticalSmoothing.getValue()/100.0D : hs;
        double va = 1.0D - Math.exp(-dt/(vs*0.3D+0.001D));
        filteredY += (rawY-filteredY)*va;
        double outX = filteredX+residualX, outY = filteredY+residualY;
        int fx=(int)Math.round(outX), fy=(int)Math.round(outY);
        residualX=outX-fx; residualY=outY-fy;
        RESULT[0]=fx; RESULT[1]=fy; return RESULT;
    }

    public static void reset() { filteredX=filteredY=residualX=residualY=0.0D; lastTimeNanos=-1L; }
}
