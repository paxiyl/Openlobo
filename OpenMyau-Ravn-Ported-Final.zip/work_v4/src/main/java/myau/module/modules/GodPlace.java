package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.mixin.IAccessorMinecraft;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;

public class GodPlace extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final IntProperty placementDelay = new IntProperty("placement-delay", 0, 0, 5);
    public final ModeProperty activationMode = new ModeProperty("activation-mode", 0,
            new String[]{"TOGGLE", "HOLD"});
    public final BooleanProperty noJumpDelay = new BooleanProperty("no-jump-delay", true);
    public final BooleanProperty alerts = new BooleanProperty("alerts", false);
    public final BooleanProperty debug = new BooleanProperty("debug", false);

    private boolean fieldsInitialized = false;
    private Field jumpField;

    public GodPlace() {
        super("GodPlace", false);
        setKey(Keyboard.KEY_G);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onEnabled() {
        initializeFields();
        sendAlert("ON (delay: " + placementDelay.getValue() + ")");
    }

    @Override
    public void onDisabled() {
        sendAlert("OFF");
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) return;

        if (activationMode.getValue() == 1) {
            boolean held = Keyboard.isKeyDown(getKey());
            if (held != isEnabled()) {
                setEnabled(held);
            }
        }

        if (!isEnabled() || mc.thePlayer == null || mc.theWorld == null) return;
        initializeFields();

        // GodPlace must not interfere with normal bridging. A downward-looking
        // block placement while moving backward/strafe or sneaking is treated as
        // a bridge context and all acceleration is skipped for this tick.
        if (isBridging()) {
            return;
        }

        ItemStack held = mc.thePlayer.getHeldItem();
        boolean placingBlock = held != null
                && held.getItem() instanceof ItemBlock
                && mc.gameSettings.keyBindUseItem.isKeyDown();

        // Direct timer write every client tick while placing. The previous v27
        // implementation throttled writes and could leave 1-2 ticks of vanilla
        // delay between placements; this keeps the selected delay authoritative.
        if (placingBlock) {
            try {
                int desired = Math.max(0, placementDelay.getValue());
                ((IAccessorMinecraft) mc).setRightClickDelayTimer(desired);
            } catch (Throwable t) {
                sendDebug("delay write failed: " + t.getClass().getSimpleName());
            }
        }

        if (noJumpDelay.getValue() && jumpField != null && mc.gameSettings.keyBindJump.isKeyDown()) {
            try {
                jumpField.setBoolean(mc.thePlayer.movementInput, true);
            } catch (Throwable t) {
                sendDebug("jump field failed");
            }
        }
    }

    @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent event) {
        if (!isEnabled() || mc.thePlayer == null || event.entityPlayer != mc.thePlayer) return;
        if (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) return;
        if (isBridging()) return;

        // Intentionally do not cancel valid block-right-click events here. The old
        // face-lock cancellation could eat legitimate placement attempts and made
        // rapid placement feel slower, especially around edges/corners.
    }

    private boolean isBridging() {
        if (mc.thePlayer == null || mc.gameSettings == null) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return false;
        if (!mc.gameSettings.keyBindUseItem.isKeyDown()) return false;
        if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != MovingObjectType.BLOCK) return false;

        float pitch = mc.thePlayer.rotationPitch;
        boolean lookingDown = pitch >= 52.0F;
        boolean directionalMovement = mc.gameSettings.keyBindForward.isKeyDown()
                || mc.gameSettings.keyBindBack.isKeyDown()
                || mc.gameSettings.keyBindLeft.isKeyDown()
                || mc.gameSettings.keyBindRight.isKeyDown();
        boolean sneaking = mc.thePlayer.isSneaking();

        return lookingDown && (directionalMovement || sneaking);
    }

    private void initializeFields() {
        if (fieldsInitialized || mc.thePlayer == null) return;

        try {
            EntityPlayerSP player = mc.thePlayer;
            Field movementField = EntityPlayerSP.class.getDeclaredField("movementInput");
            movementField.setAccessible(true);
            Object movementInput = movementField.get(player);

            if (movementInput != null) {
                String[] names = {"jump", "field_78800_z"};
                for (String name : names) {
                    try {
                        Field f = movementInput.getClass().getDeclaredField(name);
                        f.setAccessible(true);
                        jumpField = f;
                        break;
                    } catch (NoSuchFieldException ignored) {
                    }
                }
            }
        } catch (Throwable t) {
            sendDebug("jump field init failed");
        }

        fieldsInitialized = true;
    }

    private void sendAlert(String text) {
        if (!alerts.getValue() || mc.thePlayer == null) return;
        mc.thePlayer.addChatMessage(new ChatComponentText("\u00a75[GodPlace] \u00a7f" + text));
    }

    private void sendDebug(String text) {
        if (!debug.getValue() || mc.thePlayer == null) return;
        mc.thePlayer.addChatMessage(new ChatComponentText("\u00a78[GP-DEBUG] \u00a77" + text));
    }
}
