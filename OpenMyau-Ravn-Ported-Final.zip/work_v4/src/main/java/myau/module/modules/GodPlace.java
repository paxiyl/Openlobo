package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.module.Module;
import myau.mixin.IAccessorMinecraft;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;

public class GodPlace extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final IntProperty placementDelay = new IntProperty("placement-delay", 0, 0, 5);
    public final ModeProperty activationMode = new ModeProperty("activation-mode", 0,
            new String[]{"TOGGLE", "HOLD"});
    public final BooleanProperty noJumpDelay = new BooleanProperty("no-jump-delay", true);
    public final BooleanProperty alerts = new BooleanProperty("alerts", false);
    public final BooleanProperty debug = new BooleanProperty("debug", false);

    private boolean locked = false;
    private EnumFacing lockedFace = null;
    private Field jumpField;
    private boolean fieldsInitialized = false;
    private long lastDelayWrite = 0L;

    public GodPlace() {
        super("GodPlace", false);
        setKey(Keyboard.KEY_G);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onEnabled() {
        locked = false;
        lockedFace = null;
        initializeFields();
        sendAlert("ON (delay: " + placementDelay.getValue() + ")");
    }

    @Override
    public void onDisabled() {
        locked = false;
        lockedFace = null;
        sendAlert("OFF");
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) return;

        // HOLD mode is evaluated even while the module is disabled so the
        // mode can activate without needing a second toggle event.
        if (activationMode.getValue() == 1) {
            boolean held = Keyboard.isKeyDown(getKey());
            if (held != isEnabled()) {
                setEnabled(held);
            }
        }

        if (!isEnabled() || mc.thePlayer == null || mc.theWorld == null) return;

        initializeFields();

        if (!mc.gameSettings.keyBindUseItem.isKeyDown()) {
            locked = false;
            lockedFace = null;
        }

        // Keep Minecraft's vanilla placement timer at or below our selected
        // delay. Writing only when needed avoids unnecessary reflective work.
        if (lastDelayWrite + 5L <= System.currentTimeMillis()) {
            try {
                int current = ((IAccessorMinecraft) mc).getRightClickDelayTimer();
                int desired = Math.max(0, placementDelay.getValue());
                if (current > desired) {
                    ((IAccessorMinecraft) mc).setRightClickDelayTimer(desired);
                }
            } catch (Throwable t) {
                sendDebug("delay write failed: " + t.getClass().getSimpleName());
            }
            lastDelayWrite = System.currentTimeMillis();
        }

        if (noJumpDelay.getValue() && jumpField != null && mc.gameSettings.keyBindJump.isKeyDown()) {
            try {
                jumpField.setBoolean(mc.thePlayer.movementInput, true);
            } catch (Throwable t) {
                sendDebug("jump field failed");
            }
        }
    }

    @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent event) {
        if (!isEnabled() || mc.thePlayer == null || event.entityPlayer != mc.thePlayer) return;
        if (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return;

        EnumFacing hitFace = event.face;

        if (hitFace == EnumFacing.DOWN) {
            event.setCanceled(true);
            return;
        }

        if (!locked) {
            locked = true;
            lockedFace = hitFace;
            sendDebug("LOCKED " + hitFace.name());
            return;
        }

        if (hitFace != lockedFace) {
            event.setCanceled(true);
            return;
        }

        // If a fallback timer is ever needed, honor it here too.
        if (placementDelay.getValue() > 0
                && ((IAccessorMinecraft) mc).getRightClickDelayTimer() > placementDelay.getValue()) {
            event.setCanceled(true);
        }
    }

    private void initializeFields() {
        if (fieldsInitialized || mc.thePlayer == null) return;

        try {
            EntityPlayerSP player = mc.thePlayer;
            Field movementField = EntityPlayerSP.class.getDeclaredField("movementInput");
            movementField.setAccessible(true);
            Object movementInput = movementField.get(player);

            if (movementInput != null) {
                String[] names = {"jump", "field_78800_z"};
                for (String name : names) {
                    try {
                        Field f = movementInput.getClass().getDeclaredField(name);
                        f.setAccessible(true);
                        jumpField = f;
                        break;
                    } catch (NoSuchFieldException ignored) {
                    }
                }
            }
        } catch (Throwable t) {
            sendDebug("jump field init failed");
        }

        fieldsInitialized = true;
    }

    private void sendAlert(String text) {
        if (!alerts.getValue() || mc.thePlayer == null) return;
        mc.thePlayer.addChatMessage(new ChatComponentText(
                "\u00a75[GodPlace] \u00a7f" + text
        ));
    }

    private void sendDebug(String text) {
        if (!debug.getValue() || mc.thePlayer == null) return;
        mc.thePlayer.addChatMessage(new ChatComponentText(
                "\u00a78[GP-DEBUG] \u00a77" + text
        ));
    }
}
