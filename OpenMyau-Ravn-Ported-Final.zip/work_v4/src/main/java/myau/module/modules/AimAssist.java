package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.Render2DEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.ItemUtil;
import myau.util.RotationUtil;
import myau.util.TeamUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.util.Vec3;
import net.minecraft.item.ItemBlock;
import org.lwjgl.input.Mouse;

import java.util.Comparator;

/**
 * AimAssist port based on the Ravn implementation.
 *
 * Rotation is applied directly during Render2D instead of through RotationManager.
 * This avoids competing interpolation/rotation writers and removes the oscillation
 * that was visible while strafing.
 */
public class AimAssist extends Module {
    private static final Minecraft MC = Minecraft.getMinecraft();

    // Ravn-style controls. Existing property names are retained for config compatibility.
    public final FloatProperty hSpeed = new FloatProperty("horizontal-speed", 60.0F, 5.0F, 150.0F);
    public final FloatProperty vSpeed = new FloatProperty("vertical-speed", 55.0F, 0.0F, 150.0F);
    public final IntProperty smoothing = new IntProperty("smoothing", 55, 0, 100);
    public final FloatProperty range = new FloatProperty("range", 4.0F, 1.0F, 8.0F);
    public final IntProperty fov = new IntProperty("fov", 90, 10, 360);
    public final BooleanProperty clickAim = new BooleanProperty("only-while-clicking", true);
    public final BooleanProperty comboAim = new BooleanProperty("combo-auto-aim", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("weapons-only", false);
    public final BooleanProperty breakBlocks = new BooleanProperty("break-blocks", true);
    public final FloatProperty blockPlaceBlend = new FloatProperty("block-place-blend", 0.25F, 0.0F, 1.0F);
    public final BooleanProperty allowTools = new BooleanProperty("allow-tools", false, () -> weaponOnly.getValue());
    public final BooleanProperty botChecks = new BooleanProperty("bot-check", true);
    public final BooleanProperty team = new BooleanProperty("teams", true);

    private EntityPlayer activeTarget;
    private EntityPlayer comboTarget;
    private int comboCount;
    private int prevComboTargetHurtTime;
    private float prevComboDistance;
    private boolean comboAimActive;

    private long lastFrameNanos = -1L;

    private double smoothPointX;
    private double smoothPointZ;
    private boolean hasSmoothPoint;
    private double targetVelX;
    private double targetVelZ;

    public AimAssist() {
        super("AimAssist", false);
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || MC.thePlayer == null || !(event.getTarget() instanceof EntityPlayer)) return;

        EntityPlayer target = (EntityPlayer) event.getTarget();
        if (target == MC.thePlayer || target.isDead || !target.isEntityAlive()) return;

        // An attack starts/continues the current combo candidate. The combo counter
        // itself is advanced only when the target actually enters hurtTime.
        if (comboTarget != target) {
            comboTarget = target;
            comboCount = 0;
            comboAimActive = false;
            prevComboTargetHurtTime = target.hurtTime;
            prevComboDistance = MC.thePlayer.getDistanceToEntity(target);
        }
    }

    /**
     * Update combo state on the normal tick path. Aim application itself is Render2D,
     * matching Ravn's framerate-independent rotation path.
     */
    @EventTarget
    public void onTick(TickEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE || MC.thePlayer == null || MC.theWorld == null || MC.currentScreen != null) {
            if (!isEnabled()) resetTracking(false);
            return;
        }
        updateComboState();
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!isEnabled() || MC.thePlayer == null || MC.theWorld == null || MC.currentScreen != null) {
            resetTracking(true);
            return;
        }

        // KillAura owns rotations while it is active; don't fight it.
        KillAura aura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
        if (aura != null && aura.isEnabled()) {
            resetTracking(true);
            return;
        }

        double dt = getDeltaSeconds();
        if (!shouldAssist()) {
            resetTracking(true);
            return;
        }

        updateTarget();
        if (activeTarget == null) {
            resetTracking(true);
            return;
        }

        // TargetStrafe owns the horizontal orbit/yaw. AimAssist should only assist pitch
        // while it is actively steering around a target, otherwise the two modules fight.
        TargetStrafe targetStrafe = (TargetStrafe) Myau.moduleManager.getModule(TargetStrafe.class);
        boolean targetStrafeOwnsYaw = targetStrafe != null && targetStrafe.isEnabled()
                && targetStrafe.getTargetYaw() == targetStrafe.getTargetYaw(); // NaN check

        applyAim(dt, targetStrafeOwnsYaw);
    }

    private double getDeltaSeconds() {
        long now = System.nanoTime();
        double dt = lastFrameNanos < 0L ? 0.016D : (now - lastFrameNanos) * 1.0E-9D;
        lastFrameNanos = now;
        return Math.max(0.0005D, Math.min(0.05D, dt));
    }

    private void updateComboState() {
        if (!comboAim.getValue() || comboTarget == null) {
            if (!comboAim.getValue()) resetCombo();
            return;
        }

        // Taking damage immediately ends the free-aim phase. The next attack can
        // start a fresh combo, and clickAim becomes the only gate again.
        if (MC.thePlayer.hurtTime > 0) {
            resetCombo();
            return;
        }

        if (comboTarget.isDead || !comboTarget.isEntityAlive()) {
            resetCombo();
            return;
        }

        // Count actual damage transitions, not attack attempts. One transition =
        // one successful hit. After the second consecutive hit, clicking is no
        // longer required until the player gets hit.
        if (comboTarget.hurtTime > 0 && prevComboTargetHurtTime == 0) {
            comboCount++;
            if (comboCount >= 2) comboAimActive = true;
        }
        prevComboTargetHurtTime = comboTarget.hurtTime;

        float currentDistance = MC.thePlayer.getDistanceToEntity(comboTarget);
        float distDelta = currentDistance - prevComboDistance;
        prevComboDistance = currentDistance;
        if (distDelta > 0.8F || currentDistance > range.getValue() + 2.0F) {
            resetCombo();
        }
    }

    private boolean shouldAssist() {
        if (MC.gameSettings.keyBindUseItem.isKeyDown()) return false;

        if (weaponOnly.getValue() && !ItemUtil.hasRawUnbreakingEnchant()
                && !(allowTools.getValue() && ItemUtil.isHoldingTool())) {
            return false;
        }

        // Ravn behavior: when the left mouse is actually being used to break a solid
        // block, combat aim is suppressed. Looking at a block while placing is not.
        if (breakBlocks.getValue() && MC.gameSettings.keyBindAttack.isKeyDown() && MC.objectMouseOver != null
                && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK) {
            BlockPos pos = MC.objectMouseOver.getBlockPos();
            if (pos != null) {
                net.minecraft.block.Block block = MC.theWorld.getBlockState(pos).getBlock();
                if (block != Blocks.air && !(block instanceof net.minecraft.block.BlockLiquid)) {
                    return false;
                }
            }
        }

        // Normal mode: clickAim is the gate.
        // Combo mode: after 2 confirmed consecutive hits, bypass that gate until
        // the player is hit, at which point updateComboState() resets this flag.
        boolean comboActive = comboAim.getValue() && comboAimActive && comboTarget != null;
        if (comboActive) return true;
        if (!clickAim.getValue()) return true;

        // Use Minecraft's attack key state instead of the raw LWJGL mouse state so
        // the setting works consistently with normal clicking and AutoClicker.
        return MC.gameSettings.keyBindAttack.isKeyDown() && !isLookingAtBlock();
    }

    private boolean isLookingAtBlock() {
        return MC.objectMouseOver != null && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK;
    }

    private void updateTarget() {
        if (comboAimActive && comboTarget != null && isTargetUsable(comboTarget, range.getValue() + 2.0F, fov.getValue() + 15.0F)) {
            if (activeTarget != comboTarget) resetTargetSmoothing();
            activeTarget = comboTarget;
            return;
        }

        if (activeTarget != null && isTargetUsable(activeTarget, range.getValue() + 0.75F, fov.getValue() + 15.0F)) {
            return;
        }

        EntityPlayer candidate = MC.theWorld.loadedEntityList.stream()
                .filter(e -> e instanceof EntityPlayer)
                .map(e -> (EntityPlayer) e)
                .filter(this::isValidTarget)
                .min(Comparator.comparingDouble(this::distanceTo))
                .orElse(null);

        if (candidate != activeTarget) resetTargetSmoothing();
        activeTarget = candidate;
    }

    private boolean isValidTarget(EntityPlayer player) {
        return isTargetUsable(player, range.getValue(), fov.getValue());
    }

    private boolean isTargetUsable(EntityPlayer player, double maxRange, double maxFov) {
        if (player == null || player == MC.thePlayer || player.isDead || !player.isEntityAlive()) return false;
        if (MC.thePlayer.getDistanceToEntity(player) > maxRange) return false;
        if (TeamUtil.isFriend(player)) return false;
        if (team.getValue() && TeamUtil.isSameTeam(player)) return false;
        if (botChecks.getValue() && TeamUtil.isBot(player)) return false;

        float yaw = RotationUtil.getRotationsTo(
                player.posX,
                player.posY + player.getEyeHeight() * 0.5D,
                player.posZ,
                MC.thePlayer.rotationYaw,
                MC.thePlayer.rotationPitch
        )[0];
        return Math.abs(wrap(yaw - MC.thePlayer.rotationYaw)) <= maxFov;
    }

    private void applyAim(double dt, boolean targetStrafeOwnsYaw) {
        EntityPlayer target = activeTarget;
        AxisAlignedBB bb = target.getEntityBoundingBox();

        // Render2D can run hundreds of times per second. Work from the current
        // camera rotation every frame and use exponential interpolation so the
        // response is framerate-independent, smooth at 60 FPS and especially
        // buttery at high refresh/frame rates. There is intentionally no spring
        // overshoot here; that was the source of the visible strafe jitter.
        double rawX = (bb.minX + bb.maxX) * 0.5D;
        double rawZ = (bb.minZ + bb.maxZ) * 0.5D;

        double pointTau = 0.018D + (smoothing.getValue() / 100.0D) * 0.07D;
        double pointAlpha = 1.0D - Math.exp(-dt / pointTau);
        if (!hasSmoothPoint) {
            smoothPointX = rawX;
            smoothPointZ = rawZ;
            hasSmoothPoint = true;
        } else {
            smoothPointX += (rawX - smoothPointX) * pointAlpha;
            smoothPointZ += (rawZ - smoothPointZ) * pointAlpha;
        }

        // Keep prediction deliberately tiny. Large lateral prediction makes normal
        // strafing look as if the crosshair is orbiting around the target.
        double targetVelX = (target.posX - target.prevPosX) * 20.0D;
        double targetVelZ = (target.posZ - target.prevPosZ) * 20.0D;
        double prediction = 0.012D + (100.0D - smoothing.getValue()) * 0.00010D;
        double tx = smoothPointX + targetVelX * prediction;
        double tz = smoothPointZ + targetVelZ * prediction;

        double eyeY = MC.thePlayer.posY + MC.thePlayer.getEyeHeight();
        double dx = tx - MC.thePlayer.posX;
        double dz = tz - MC.thePlayer.posZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0E-4D) return;

        double desiredYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0D;
        double targetEyeY = target.posY + target.getEyeHeight() * 0.85D;
        double desiredPitch = -Math.toDegrees(Math.atan2(targetEyeY - eyeY, horizontal));
        desiredPitch = Math.max(-89.9D, Math.min(89.9D, desiredPitch));

        double effectiveBlend = 1.0D;
        if (MC.thePlayer.getHeldItem() != null
                && MC.thePlayer.getHeldItem().getItem() instanceof ItemBlock
                && MC.objectMouseOver != null
                && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK) {
            effectiveBlend = 1.0D - blockPlaceBlend.getValue();
        }

        double currentYaw = MC.thePlayer.rotationYaw;
        double currentPitch = MC.thePlayer.rotationPitch;

        // Speed is expressed as response strength rather than a per-tick step.
        // This means changing FPS does not change the feel and removes stair-step
        // motion caused by tick-sized rotation increments.
        double yawResponse = Math.max(1.0D, hSpeed.getValue());
        double pitchResponse = Math.max(1.0D, vSpeed.getValue() > 0.0F ? vSpeed.getValue() : hSpeed.getValue() * 0.85D);

        if (!targetStrafeOwnsYaw) {
            double yawError = wrap(desiredYaw - currentYaw);
            double yawAlpha = 1.0D - Math.exp(-yawResponse * dt);
            double yawStep = yawError * yawAlpha * effectiveBlend;
            currentYaw += yawStep;
        }

        double pitchError = desiredPitch - currentPitch;
        double pitchAlpha = 1.0D - Math.exp(-pitchResponse * dt);
        double pitchStep = pitchError * pitchAlpha * effectiveBlend;
        currentPitch += pitchStep;

        MC.thePlayer.rotationYaw = (float) currentYaw;
        MC.thePlayer.rotationPitch = (float) Math.max(-90.0D, Math.min(90.0D, currentPitch));
    }

    private boolean hasLineOfSight(EntityPlayer target) {
        Vec3 eye = new Vec3(MC.thePlayer.posX, MC.thePlayer.posY + MC.thePlayer.getEyeHeight(), MC.thePlayer.posZ);
        AxisAlignedBB bb = target.getEntityBoundingBox();
        Vec3 point = new Vec3((bb.minX + bb.maxX) * 0.5D, (bb.minY + bb.maxY) * 0.5D, (bb.minZ + bb.maxZ) * 0.5D);
        return MC.theWorld.rayTraceBlocks(eye, point) == null;
    }

    private double distanceTo(EntityPlayer player) {
        return MC.thePlayer.getDistanceToEntity(player);
    }

    private double wrap(double value) {
        while (value <= -180.0F) value += 360.0F;
        while (value > 180.0F) value -= 360.0F;
        return value;
    }

    private void resetTargetSmoothing() {
        hasSmoothPoint = false;
    }

    private void resetTracking(boolean softReset) {
        activeTarget = null;
        resetTargetSmoothing();
        if (!softReset) lastFrameNanos = -1L;
    }

    private void resetCombo() {
        comboTarget = null;
        comboCount = 0;
        prevComboTargetHurtTime = 0;
        prevComboDistance = 0.0F;
        comboAimActive = false;
    }

    @Override
    public void onEnabled() {
        resetTracking(false);
        resetCombo();
    }

    @Override
    public void onDisabled() {
        resetTracking(false);
        resetCombo();
    }

    public EntityPlayer getEnemy() {
        return activeTarget;
    }
}
