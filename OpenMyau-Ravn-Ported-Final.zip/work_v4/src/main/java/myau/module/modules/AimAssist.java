package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.Render2DEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.ItemUtil;
import myau.util.RotationUtil;
import myau.util.TeamUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.util.Vec3;
import net.minecraft.item.ItemBlock;
import org.lwjgl.input.Mouse;

import java.util.Comparator;

/**
 * AimAssist port based on the Ravn implementation.
 *
 * Rotation is applied directly during Render2D instead of through RotationManager.
 * This avoids competing interpolation/rotation writers and removes the oscillation
 * that was visible while strafing.
 */
public class AimAssist extends Module {
    private static final Minecraft MC = Minecraft.getMinecraft();

    // Ravn-style controls. Existing property names are retained for config compatibility.
    public final FloatProperty hSpeed = new FloatProperty("horizontal-speed", 24.0F, 4.0F, 100.0F);
    public final FloatProperty vSpeed = new FloatProperty("vertical-speed", 18.0F, 0.0F, 100.0F);
    public final IntProperty smoothing = new IntProperty("smoothing", 50, 0, 100);
    public final FloatProperty range = new FloatProperty("range", 4.0F, 1.0F, 8.0F);
    public final IntProperty fov = new IntProperty("fov", 90, 10, 360);
    public final BooleanProperty clickAim = new BooleanProperty("only-while-clicking", true);
    public final BooleanProperty comboAim = new BooleanProperty("combo-auto-aim", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("weapons-only", false);
    public final BooleanProperty breakBlocks = new BooleanProperty("break-blocks", true);
    public final FloatProperty blockPlaceBlend = new FloatProperty("block-place-blend", 0.25F, 0.0F, 1.0F);
    public final BooleanProperty allowTools = new BooleanProperty("allow-tools", false, () -> weaponOnly.getValue());
    public final BooleanProperty botChecks = new BooleanProperty("bot-check", true);
    public final BooleanProperty team = new BooleanProperty("teams", true);

    private EntityPlayer activeTarget;
    private EntityPlayer comboTarget;
    private int comboCount;
    private int prevComboTargetHurtTime;
    private float prevComboDistance;
    private boolean comboAimActive;

    private long lastFrameNanos = -1L;
    private boolean hasLastAppliedRotation;
    private double lastAppliedYaw;
    private double lastAppliedPitch;
    private double manualHoldTimer;
    private double blend = 1.0D;
    private double velYaw;
    private double velPitch;

    private double smoothPointX;
    private double smoothPointZ;
    private boolean hasSmoothPoint;
    private double targetVelX;
    private double targetVelZ;

    public AimAssist() {
        super("AimAssist", false);
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || !(event.getTarget() instanceof EntityPlayer) || MC.thePlayer == null) return;
        EntityPlayer target = (EntityPlayer) event.getTarget();
        if (target == MC.thePlayer) return;

        if (comboTarget != target) {
            comboTarget = target;
            comboCount = 0;
            comboAimActive = false;
            prevComboTargetHurtTime = target.hurtTime;
            prevComboDistance = MC.thePlayer.getDistanceToEntity(target);
        }
    }

    /**
     * Update combo state on the normal tick path. Aim application itself is Render2D,
     * matching Ravn's framerate-independent rotation path.
     */
    @EventTarget
    public void onTick(TickEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE || MC.thePlayer == null || MC.theWorld == null || MC.currentScreen != null) {
            if (!isEnabled()) resetTracking(false);
            return;
        }
        updateComboState();
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!isEnabled() || MC.thePlayer == null || MC.theWorld == null || MC.currentScreen != null) {
            resetTracking(true);
            return;
        }

        // KillAura owns rotations while it is active; don't fight it.
        KillAura aura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
        if (aura != null && aura.isEnabled()) {
            resetTracking(true);
            return;
        }

        double dt = getDeltaSeconds();
        if (!shouldAssist()) {
            resetTracking(true);
            return;
        }

        updateTarget();
        if (activeTarget == null) {
            resetTracking(true);
            return;
        }

        // TargetStrafe owns the horizontal orbit/yaw. AimAssist should only assist pitch
        // while it is actively steering around a target, otherwise the two modules fight.
        TargetStrafe targetStrafe = (TargetStrafe) Myau.moduleManager.getModule(TargetStrafe.class);
        boolean targetStrafeOwnsYaw = targetStrafe != null && targetStrafe.isEnabled()
                && targetStrafe.getTargetYaw() == targetStrafe.getTargetYaw(); // NaN check

        applyAim(dt, targetStrafeOwnsYaw);
    }

    private double getDeltaSeconds() {
        long now = System.nanoTime();
        double dt = lastFrameNanos < 0L ? 0.016D : (now - lastFrameNanos) * 1.0E-9D;
        lastFrameNanos = now;
        return Math.max(0.0005D, Math.min(0.05D, dt));
    }

    private void updateComboState() {
        if (!comboAim.getValue() || comboTarget == null) {
            resetCombo();
            return;
        }

        if (MC.thePlayer.hurtTime > 0 || comboTarget.isDead || !comboTarget.isEntityAlive() || !hasLineOfSight(comboTarget)) {
            resetCombo();
            return;
        }

        if (comboTarget.hurtTime > 0 && prevComboTargetHurtTime == 0) {
            comboCount++;
            comboAimActive = comboCount >= 2;
        }
        prevComboTargetHurtTime = comboTarget.hurtTime;

        float currentDistance = MC.thePlayer.getDistanceToEntity(comboTarget);
        float distDelta = currentDistance - prevComboDistance;
        prevComboDistance = currentDistance;
        if (distDelta > 0.8F || currentDistance > range.getValue() + 2.0F) {
            resetCombo();
        }
    }

    private boolean shouldAssist() {
        if (MC.gameSettings.keyBindUseItem.isKeyDown()) return false;

        if (weaponOnly.getValue() && !ItemUtil.hasRawUnbreakingEnchant()
                && !(allowTools.getValue() && ItemUtil.isHoldingTool())) {
            return false;
        }

        // Ravn behavior: when the left mouse is actually being used to break a solid
        // block, combat aim is suppressed. Looking at a block while placing is not.
        if (breakBlocks.getValue() && Mouse.isButtonDown(0) && MC.objectMouseOver != null
                && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK) {
            BlockPos pos = MC.objectMouseOver.getBlockPos();
            if (pos != null) {
                net.minecraft.block.Block block = MC.theWorld.getBlockState(pos).getBlock();
                if (block != Blocks.air && !(block instanceof net.minecraft.block.BlockLiquid)) {
                    return false;
                }
            }
        }

        boolean comboActive = comboAim.getValue() && comboAimActive && comboTarget != null && hasLineOfSight(comboTarget);
        if (comboActive) return true;
        if (!clickAim.getValue()) return true;

        AutoClicker autoClicker = (AutoClicker) Myau.moduleManager.getModule(AutoClicker.class);
        if (autoClicker != null && autoClicker.isEnabled()) return false;
        return Mouse.isButtonDown(0) && !isLookingAtBlock();
    }

    private boolean isLookingAtBlock() {
        return MC.objectMouseOver != null && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK;
    }

    private void updateTarget() {
        if (comboAimActive && comboTarget != null && isTargetUsable(comboTarget, range.getValue() + 2.0F, fov.getValue() + 15.0F)) {
            if (activeTarget != comboTarget) resetTargetSmoothing();
            activeTarget = comboTarget;
            return;
        }

        if (activeTarget != null && isTargetUsable(activeTarget, range.getValue() + 0.75F, fov.getValue() + 15.0F)) {
            return;
        }

        EntityPlayer candidate = MC.theWorld.loadedEntityList.stream()
                .filter(e -> e instanceof EntityPlayer)
                .map(e -> (EntityPlayer) e)
                .filter(this::isValidTarget)
                .min(Comparator.comparingDouble(this::distanceTo))
                .orElse(null);

        if (candidate != activeTarget) resetTargetSmoothing();
        activeTarget = candidate;
    }

    private boolean isValidTarget(EntityPlayer player) {
        return isTargetUsable(player, range.getValue(), fov.getValue());
    }

    private boolean isTargetUsable(EntityPlayer player, double maxRange, double maxFov) {
        if (player == null || player == MC.thePlayer || player.isDead || !player.isEntityAlive()) return false;
        if (MC.thePlayer.getDistanceToEntity(player) > maxRange) return false;
        if (TeamUtil.isFriend(player)) return false;
        if (team.getValue() && TeamUtil.isSameTeam(player)) return false;
        if (botChecks.getValue() && TeamUtil.isBot(player)) return false;

        float yaw = RotationUtil.getRotationsTo(
                player.posX,
                player.posY + player.getEyeHeight() * 0.5D,
                player.posZ,
                MC.thePlayer.rotationYaw,
                MC.thePlayer.rotationPitch
        )[0];
        return Math.abs(wrap(yaw - MC.thePlayer.rotationYaw)) <= maxFov;
    }

    private void applyAim(double dt, boolean targetStrafeOwnsYaw) {
        EntityPlayer target = activeTarget;
        AxisAlignedBB bb = target.getEntityBoundingBox();

        double rawX = (bb.minX + bb.maxX) * 0.5D;
        double rawZ = (bb.minZ + bb.maxZ) * 0.5D;
        targetVelX = (target.posX - target.prevPosX) * 20.0D;
        targetVelZ = (target.posZ - target.prevPosZ) * 20.0D;

        // Exponential target-point smoothing. This filters jitter without introducing
        // the large oscillations the old RotationManager path produced while strafing.
        double smoothingStrength = smoothing.getValue() / 100.0D;
        double tau = 0.02D + (1.0D - smoothingStrength) * 0.16D;
        double alpha = 1.0D - Math.exp(-dt / tau);
        if (!hasSmoothPoint) {
            smoothPointX = rawX;
            smoothPointZ = rawZ;
            hasSmoothPoint = true;
        } else {
            smoothPointX += (rawX - smoothPointX) * alpha;
            smoothPointZ += (rawZ - smoothPointZ) * alpha;
        }

        // Keep prediction modest; excessive lead is what made lateral strafe movement
        // look like the aim was rotating around the target.
        double prediction = 0.04D + 0.04D * smoothingStrength;
        double tx = smoothPointX + targetVelX * prediction;
        double tz = smoothPointZ + targetVelZ * prediction;

        double eyeY = MC.thePlayer.posY + MC.thePlayer.getEyeHeight();
        double dx = tx - MC.thePlayer.posX;
        double dz = tz - MC.thePlayer.posZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0E-4D) return;

        double desiredYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0D;
        double pitchTop = -Math.toDegrees(Math.atan2(bb.maxY - eyeY, horizontal));
        double pitchBottom = -Math.toDegrees(Math.atan2(bb.minY - eyeY, horizontal));
        double curPitch = MC.thePlayer.rotationPitch;
        double desiredPitch;
        if (curPitch < pitchTop + 0.75D) desiredPitch = pitchTop + 0.75D;
        else if (curPitch > pitchBottom - 0.75D) desiredPitch = pitchBottom - 0.75D;
        else desiredPitch = curPitch;
        desiredPitch = Math.max(-89.9D, Math.min(89.9D, desiredPitch));

        float curYaw = MC.thePlayer.rotationYaw;
        float curPitchF = MC.thePlayer.rotationPitch;
        if (!hasLastAppliedRotation) {
            lastAppliedYaw = curYaw;
            lastAppliedPitch = curPitchF;
            hasLastAppliedRotation = true;
        }

        double manualYaw = wrap(curYaw - lastAppliedYaw);
        double manualPitch = curPitchF - lastAppliedPitch;
        double manualMagnitude = Math.sqrt(manualYaw * manualYaw + manualPitch * manualPitch);
        if (manualMagnitude > 0.6D) manualHoldTimer = 0.12D;
        else manualHoldTimer = Math.max(0.0D, manualHoldTimer - dt);

        double targetBlend = manualHoldTimer > 0.0D ? 0.70D : 1.0D;
        blend += (targetBlend - blend) * (1.0D - Math.exp(-dt / 0.18D));

        // When placing blocks, reduce the combat pull by the configurable blend amount
        // instead of disabling AimAssist completely.
        double placementBlend = 1.0D;
        if (MC.thePlayer.getHeldItem() != null && MC.thePlayer.getHeldItem().getItem() instanceof ItemBlock
                && MC.objectMouseOver != null && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK) {
            placementBlend = 1.0D - blockPlaceBlend.getValue();
        }
        double effectiveBlend = blend * Math.max(0.0D, Math.min(1.0D, placementBlend));

        double currentYaw = curYaw;
        double currentPitch = curPitchF;

        if (!targetStrafeOwnsYaw) {
            double errYaw = wrap((float) (desiredYaw - currentYaw));
            double omegaH = Math.max(4.0D, hSpeed.getValue());
            double moveYaw = springStep(errYaw * effectiveBlend, velYaw, omegaH, dt);
            velYaw = moveYaw / Math.max(dt, 0.0005D);
            double maxYawStep = Math.max(1.0D, hSpeed.getValue() * 2.0D) * dt;
            moveYaw = Math.max(-maxYawStep, Math.min(maxYawStep, moveYaw));
            if (Math.abs(errYaw) < 0.05D) {
                moveYaw = 0.0D;
                velYaw *= Math.exp(-10.0D * dt);
            }
            currentYaw += moveYaw;
        }

        double errPitch = desiredPitch - currentPitch;
        double omegaV = Math.max(2.0D, vSpeed.getValue() <= 0.0F ? hSpeed.getValue() * 0.75D : vSpeed.getValue());
        double movePitch = springStep(errPitch * effectiveBlend, velPitch, omegaV, dt);
        velPitch = movePitch / Math.max(dt, 0.0005D);
        double maxPitchStep = Math.max(0.5D, omegaV * 1.5D) * dt;
        movePitch = Math.max(-maxPitchStep, Math.min(maxPitchStep, movePitch));
        if (Math.abs(errPitch) < 0.05D) {
            movePitch = 0.0D;
            velPitch *= Math.exp(-10.0D * dt);
        }
        currentPitch += movePitch;

        MC.thePlayer.rotationYaw = (float) currentYaw;
        MC.thePlayer.rotationPitch = (float) Math.max(-90.0D, Math.min(90.0D, currentPitch));
        lastAppliedYaw = MC.thePlayer.rotationYaw;
        lastAppliedPitch = MC.thePlayer.rotationPitch;
    }

    private double springStep(double error, double velocity, double omega, double dt) {
        double stiffness = omega * omega;
        double damping = 2.0D * omega;
        double newVelocity = velocity + (stiffness * error - damping * velocity) * dt;
        return (velocity + newVelocity) * 0.5D * dt;
    }

    private boolean hasLineOfSight(EntityPlayer target) {
        Vec3 eye = new Vec3(MC.thePlayer.posX, MC.thePlayer.posY + MC.thePlayer.getEyeHeight(), MC.thePlayer.posZ);
        AxisAlignedBB bb = target.getEntityBoundingBox();
        Vec3 point = new Vec3((bb.minX + bb.maxX) * 0.5D, (bb.minY + bb.maxY) * 0.5D, (bb.minZ + bb.maxZ) * 0.5D);
        return MC.theWorld.rayTraceBlocks(eye, point) == null;
    }

    private double distanceTo(EntityPlayer player) {
        return MC.thePlayer.getDistanceToEntity(player);
    }

    private float wrap(float value) {
        while (value <= -180.0F) value += 360.0F;
        while (value > 180.0F) value -= 360.0F;
        return value;
    }

    private void resetTargetSmoothing() {
        hasSmoothPoint = false;
        targetVelX = 0.0D;
        targetVelZ = 0.0D;
        velYaw = 0.0D;
        velPitch = 0.0D;
    }

    private void resetTracking(boolean softReset) {
        activeTarget = null;
        resetTargetSmoothing();
        hasLastAppliedRotation = false;
        manualHoldTimer = 0.0D;
        blend = 1.0D;
        if (!softReset) lastFrameNanos = -1L;
    }

    private void resetCombo() {
        comboTarget = null;
        comboCount = 0;
        prevComboTargetHurtTime = 0;
        prevComboDistance = 0.0F;
        comboAimActive = false;
    }

    @Override
    public void onEnabled() {
        resetTracking(false);
        resetCombo();
    }

    @Override
    public void onDisabled() {
        resetTracking(false);
        resetCombo();
    }

    public EntityPlayer getEnemy() {
        return activeTarget;
    }
}
