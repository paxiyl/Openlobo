package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.KeyEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.util.*;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.PercentProperty;
import myau.property.properties.IntProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AimAssist extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private final TimerUtil timer = new TimerUtil();
    public final FloatProperty hSpeed = new FloatProperty("horizontal-speed", 5.0F, 0.0F, 10.0F);
    public final FloatProperty vSpeed = new FloatProperty("vertical-speed", 0.0F, 0.0F, 10.0F);
    public final PercentProperty smoothing = new PercentProperty("smoothing", 50);
    public final FloatProperty range = new FloatProperty("range", 4.5F, 3.0F, 8.0F);
    public final IntProperty fov = new IntProperty("fov", 90, 30, 360);
    public final BooleanProperty clickAim = new BooleanProperty("only-while-clicking", true);
    public final BooleanProperty comboAim = new BooleanProperty("combo-aim", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("weapons-only", true);
    public final BooleanProperty allowTools = new BooleanProperty("allow-tools", false, this.weaponOnly::getValue);
    public final BooleanProperty botChecks = new BooleanProperty("bot-check", true);
    public final BooleanProperty team = new BooleanProperty("teams", true);

    private EntityPlayer comboTarget;
    private int comboHits;
    private int lastComboTargetHurtTime;
    private int lastPlayerHurtTime;
    private boolean comboActive;

    private void resetCombo() {
        comboTarget = null;
        comboHits = 0;
        lastComboTargetHurtTime = 0;
        comboActive = false;
    }

    private void updateComboState() {
        if (!this.comboAim.getValue() || mc.thePlayer == null) {
            resetCombo();
            return;
        }

        // Any new incoming hit immediately ends the click-bypass state.
        if (mc.thePlayer.hurtTime > 0 && lastPlayerHurtTime <= 0) {
            resetCombo();
        }
        lastPlayerHurtTime = mc.thePlayer.hurtTime;

        if (comboTarget == null || comboTarget.isDead || !isValidTarget(comboTarget)) {
            if (!comboActive) {
                comboTarget = null;
                comboHits = 0;
            } else {
                resetCombo();
            }
            return;
        }

        // Count only real target hurt transitions, not attack attempts.
        if (comboTarget.hurtTime > 0 && lastComboTargetHurtTime <= 0) {
            comboHits++;
            if (comboHits >= 2) {
                comboActive = true;
            }
        }
        lastComboTargetHurtTime = comboTarget.hurtTime;
    }

    private boolean shouldAssist() {
        if (!this.clickAim.getValue()) {
            return true;
        }
        return PlayerUtil.isAttacking() || (this.comboAim.getValue() && comboActive);
    }

    private boolean isValidTarget(EntityPlayer entityPlayer) {
        if (entityPlayer != mc.thePlayer && entityPlayer != mc.thePlayer.ridingEntity) {
            if (entityPlayer == mc.getRenderViewEntity() || entityPlayer == mc.getRenderViewEntity().ridingEntity) {
                return false;
            } else if (entityPlayer.deathTime > 0) {
                return false;
            } else if (RotationUtil.distanceToEntity(entityPlayer) > (double) this.range.getValue()) {
                return false;
            } else if (RotationUtil.angleToEntity(entityPlayer) > (float) this.fov.getValue()) {
                return false;
            } else if (RotationUtil.rayTrace(entityPlayer) != null) {
                return false;
            } else if (TeamUtil.isFriend(entityPlayer)) {
                return false;
            } else {
                return (!this.team.getValue() || !TeamUtil.isSameTeam(entityPlayer)) && (!this.botChecks.getValue() || !TeamUtil.isBot(entityPlayer));
            }
        } else {
            return false;
        }
    }

    private boolean isInReach(EntityPlayer entityPlayer) {
        Reach reach = (Reach) Myau.moduleManager.modules.get(Reach.class);
        double distance = reach.isEnabled() ? (double) reach.range.getValue() : 3.0;
        return RotationUtil.distanceToEntity(entityPlayer) <= distance;
    }

    private boolean isLookingAtBlock() {
        return mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == MovingObjectType.BLOCK;
    }

    public AimAssist() {
        super("AimAssist", false);
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!this.isEnabled() || !this.comboAim.getValue() || !(event.getTarget() instanceof EntityPlayer)) {
            return;
        }

        EntityPlayer target = (EntityPlayer) event.getTarget();
        if (isValidTarget(target)) {
            if (comboTarget != target) {
                comboTarget = target;
                comboHits = 0;
                comboActive = false;
                lastComboTargetHurtTime = target.hurtTime;
            }
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.POST && mc.currentScreen == null) {
            updateComboState();
            if (!shouldAssist()) {
                return;
            }
            if (!(Boolean) this.weaponOnly.getValue()
                    || ItemUtil.hasRawUnbreakingEnchant()
                    || this.allowTools.getValue() && ItemUtil.isHoldingTool()) {
                boolean attacking = PlayerUtil.isAttacking();
                if (!attacking || !this.isLookingAtBlock()) {
                    if (attacking || comboActive || !this.timer.hasTimeElapsed(350L)) {
                        List<EntityPlayer> inRange;
                        if (comboActive && comboTarget != null && isValidTarget(comboTarget)) {
                            inRange = new java.util.ArrayList<>();
                            inRange.add(comboTarget);
                        } else {
                            inRange = mc.theWorld
                                .loadedEntityList
                                .stream()
                                .filter(entity -> entity instanceof EntityPlayer)
                                .map(entity -> (EntityPlayer) entity)
                                .filter(this::isValidTarget)
                                .sorted(Comparator.comparingDouble(RotationUtil::distanceToEntity))
                                .collect(Collectors.toList());
                        }
                        if (!inRange.isEmpty()) {
                            if (inRange.stream().anyMatch(this::isInReach)) {
                                inRange.removeIf(entityPlayer -> !this.isInReach(entityPlayer));
                            }
                            EntityPlayer player = inRange.get(0);
                            if (!(RotationUtil.distanceToEntity(player) <= 0.0)) {
                                AxisAlignedBB axisAlignedBB = player.getEntityBoundingBox();
                                double collisionBorderSize = player.getCollisionBorderSize();
                                float[] rotation = RotationUtil.getRotationsToBox(
                                        axisAlignedBB.expand(collisionBorderSize, collisionBorderSize, collisionBorderSize),
                                        mc.thePlayer.rotationYaw,
                                        mc.thePlayer.rotationPitch,
                                        180.0F,
                                        (float) this.smoothing.getValue() / 100.0F
                                );
                                float yaw = Math.min(Math.abs(this.hSpeed.getValue()), 10.0F);
                                float pitch = Math.min(Math.abs(this.vSpeed.getValue()), 10.0F);
                                float currentYaw = mc.thePlayer.rotationYaw;
                                float yawDelta = net.minecraft.util.MathHelper.wrapAngleTo180_float(rotation[0] - currentYaw);
                                float targetYaw = currentYaw + yawDelta * 0.1F * yaw;
                                float currentPitch = mc.thePlayer.rotationPitch;
                                float targetPitch = currentPitch + (rotation[1] - currentPitch) * 0.1F * pitch;
                                Myau.rotationManager.setRotation(targetYaw, targetPitch, 0, false);
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onDisabled() {
        resetCombo();
        lastPlayerHurtTime = 0;
        this.timer.reset();
    }

    @EventTarget
    public void onPress(KeyEvent event) {
        if (event.getKey() == mc.gameSettings.keyBindAttack.getKeyCode() && !Myau.moduleManager.modules.get(AutoClicker.class).isEnabled()) {
            this.timer.reset();
        }
    }
}
