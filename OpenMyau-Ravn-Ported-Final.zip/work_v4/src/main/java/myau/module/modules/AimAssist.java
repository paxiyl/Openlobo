package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.KeyEvent;
import myau.events.TickEvent;
import myau.mixin.IAccessorPlayerControllerMP;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.PercentProperty;
import myau.util.ItemUtil;
import myau.util.PlayerUtil;
import myau.util.RotationUtil;
import myau.util.TeamUtil;
import myau.util.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AimAssist extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private final TimerUtil timer = new TimerUtil();

    public final FloatProperty hSpeed = new FloatProperty("horizontal-speed", 5.0F, 0.0F, 10.0F);
    public final FloatProperty vSpeed = new FloatProperty("vertical-speed", 0.0F, 0.0F, 10.0F);
    public final PercentProperty smoothing = new PercentProperty("smoothing", 50);
    public final FloatProperty range = new FloatProperty("range", 4.5F, 3.0F, 8.0F);
    public final IntProperty fov = new IntProperty("fov", 90, 30, 360);
    public final BooleanProperty clickAim = new BooleanProperty("only-while-clicking", true);
    public final BooleanProperty comboAim = new BooleanProperty("combo-aim", true);
    public final BooleanProperty combatThroughBlocks = new BooleanProperty("combat-through-blocks", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("weapons-only", false);
    public final BooleanProperty allowTools = new BooleanProperty("allow-tools", false, this.weaponOnly::getValue);
    public final BooleanProperty botChecks = new BooleanProperty("bot-check", true);
    public final BooleanProperty team = new BooleanProperty("teams", true);

    private EntityPlayer comboTarget;
    private int comboHits;
    private int lastComboTargetHurtTime;
    private int lastPlayerHurtTime;
    private boolean comboActive;
    private long lastCombatAttackAt;

    private BlockPos breakFocusPos;
    private long breakFocusStarted;

    public AimAssist() {
        super("AimAssist", false);
    }

    private void resetCombo() {
        comboTarget = null;
        comboHits = 0;
        lastComboTargetHurtTime = 0;
        comboActive = false;
    }

    private void resetBlockFocus() {
        breakFocusPos = null;
        breakFocusStarted = 0L;
    }

    private void updateComboState() {
        if (!this.comboAim.getValue() || mc.thePlayer == null) {
            resetCombo();
            return;
        }

        if (mc.thePlayer.hurtTime > 0 && lastPlayerHurtTime <= 0) {
            resetCombo();
        }
        lastPlayerHurtTime = mc.thePlayer.hurtTime;

        if (comboTarget == null || comboTarget.isDead || !isCombatTarget(comboTarget, false)) {
            if (!comboActive) {
                comboTarget = null;
                comboHits = 0;
            } else {
                resetCombo();
            }
            return;
        }

        if (comboTarget.hurtTime > 0 && lastComboTargetHurtTime <= 0) {
            comboHits++;
            if (comboHits >= 2) {
                comboActive = true;
            }
        }
        lastComboTargetHurtTime = comboTarget.hurtTime;
    }

    private boolean shouldAssist() {
        if (!this.clickAim.getValue()) {
            return true;
        }
        return PlayerUtil.isAttacking() || (this.comboAim.getValue() && comboActive);
    }

    private boolean isCombatTarget(EntityPlayer entityPlayer, boolean ignoreBlocks) {
        if (entityPlayer == null || entityPlayer == mc.thePlayer || entityPlayer == mc.thePlayer.ridingEntity) {
            return false;
        }
        if (entityPlayer == mc.getRenderViewEntity() || entityPlayer == mc.getRenderViewEntity().ridingEntity) {
            return false;
        }
        if (entityPlayer.deathTime > 0 || entityPlayer.isDead || !entityPlayer.isEntityAlive()) {
            return false;
        }
        if (RotationUtil.distanceToEntity(entityPlayer) > range.getValue()) {
            return false;
        }
        if (RotationUtil.angleToEntity(entityPlayer) > fov.getValue()) {
            return false;
        }
        if (!ignoreBlocks && RotationUtil.rayTrace(entityPlayer) != null) {
            return false;
        }
        if (TeamUtil.isFriend(entityPlayer)) {
            return false;
        }
        return (!team.getValue() || !TeamUtil.isSameTeam(entityPlayer))
                && (!botChecks.getValue() || !TeamUtil.isBot(entityPlayer));
    }

    private boolean isInReach(EntityPlayer entityPlayer) {
        return RotationUtil.distanceToEntity(entityPlayer) <= range.getValue();
    }

    private boolean isLookingAtBlock() {
        return mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == MovingObjectType.BLOCK;
    }

    private boolean isActivelyBreakingBlock() {
        if (!isLookingAtBlock() || mc.playerController == null) {
            resetBlockFocus();
            return false;
        }

        BlockPos pos = mc.objectMouseOver.getBlockPos();
        if (pos == null) {
            resetBlockFocus();
            return false;
        }

        if (!pos.equals(breakFocusPos)) {
            breakFocusPos = pos;
            breakFocusStarted = System.currentTimeMillis();
            return false;
        }

        IAccessorPlayerControllerMP controller = (IAccessorPlayerControllerMP) mc.playerController;
        if (!controller.getIsHittingBlock()) {
            return false;
        }

        float damage = controller.getCurBlockDamageMP();
        return damage > 0.04F || System.currentTimeMillis() - breakFocusStarted >= 90L;
    }

    private boolean hasCombatTargetThroughBlock() {
        if (!combatThroughBlocks.getValue() || mc.theWorld == null || mc.thePlayer == null) {
            return false;
        }

        return mc.theWorld.loadedEntityList.stream()
                .filter(entity -> entity instanceof EntityPlayer)
                .map(entity -> (EntityPlayer) entity)
                .filter(entity -> isCombatTarget(entity, true))
                .filter(entity -> RotationUtil.angleToEntity(entity) <= Math.min(45.0F, fov.getValue()))
                .anyMatch(entity -> RotationUtil.rayTrace(entity) != null);
    }

    private boolean shouldYieldToBlockBreak() {
        if (!isActivelyBreakingBlock()) {
            return false;
        }

        // Give deliberate mining priority only when combat is not currently
        // active. A recent successful hit or a valid enemy directly behind the
        // block means this is combat and AimAssist must keep tracking.
        boolean recentCombat = System.currentTimeMillis() - lastCombatAttackAt < 650L;
        boolean blockedCombatTarget = hasCombatTargetThroughBlock() && PlayerUtil.isAttacking();
        return !recentCombat && !blockedCombatTarget;
    }

    private List<EntityPlayer> findTargets() {
        boolean allowBlockedCombat = isLookingAtBlock() && PlayerUtil.isAttacking() && combatThroughBlocks.getValue();

        List<EntityPlayer> targets = mc.theWorld.loadedEntityList.stream()
                .filter(entity -> entity instanceof EntityPlayer)
                .map(entity -> (EntityPlayer) entity)
                .filter(entity -> isCombatTarget(entity, allowBlockedCombat))
                .sorted(Comparator.comparingDouble(RotationUtil::distanceToEntity))
                .collect(Collectors.toList());

        if (allowBlockedCombat) {
            List<EntityPlayer> throughBlockTargets = mc.theWorld.loadedEntityList.stream()
                    .filter(entity -> entity instanceof EntityPlayer)
                    .map(entity -> (EntityPlayer) entity)
                    .filter(entity -> isCombatTarget(entity, true))
                    .sorted(Comparator.comparingDouble(RotationUtil::distanceToEntity))
                    .collect(Collectors.toList());
            if (!throughBlockTargets.isEmpty()) {
                return throughBlockTargets;
            }
        }
        return targets;
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!this.isEnabled() || !this.comboAim.getValue() || event == null || !(event.getTarget() instanceof EntityPlayer)) {
            return;
        }

        EntityPlayer target = (EntityPlayer) event.getTarget();
        if (isCombatTarget(target, true)) {
            lastCombatAttackAt = System.currentTimeMillis();
            if (comboTarget != target) {
                comboTarget = target;
                comboHits = 0;
                comboActive = false;
                lastComboTargetHurtTime = target.hurtTime;
            }
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.POST || mc.currentScreen != null
                || mc.thePlayer == null || mc.theWorld == null) {
            return;
        }

        updateComboState();

        if (!shouldAssist()) {
            resetBlockFocus();
            return;
        }

        // "Weapons only" is a restriction, not a prerequisite for AimAssist.
        // Default behavior allows aiming with any held item.
        if (this.weaponOnly.getValue()
                && !ItemUtil.isHoldingSword()
                && !(this.allowTools.getValue() && ItemUtil.isHoldingTool())
                && !ItemUtil.hasRawUnbreakingEnchant()) {
            return;
        }

        boolean attacking = PlayerUtil.isAttacking();
        boolean blockUnderCrosshair = isLookingAtBlock();

        // Do not aim away from a block the player is genuinely breaking unless
        // there is an active combat target behind that block.
        if (blockUnderCrosshair && shouldYieldToBlockBreak()) {
            return;
        }

        if (attacking || comboActive || !this.timer.hasTimeElapsed(350L)) {
            List<EntityPlayer> inRange = new ArrayList<>();
            if (comboActive && comboTarget != null && isCombatTarget(comboTarget, true)) {
                inRange.add(comboTarget);
            } else {
                inRange.addAll(findTargets());
            }

            if (!inRange.isEmpty() && inRange.stream().anyMatch(this::isInReach)) {
                inRange.removeIf(entityPlayer -> !this.isInReach(entityPlayer));
            }

            if (!inRange.isEmpty()) {
                EntityPlayer player = inRange.get(0);
                AxisAlignedBB axisAlignedBB = player.getEntityBoundingBox();
                double collisionBorderSize = player.getCollisionBorderSize();
                float[] rotation = RotationUtil.getRotationsToBox(
                        axisAlignedBB.expand(collisionBorderSize, collisionBorderSize, collisionBorderSize),
                        mc.thePlayer.rotationYaw,
                        mc.thePlayer.rotationPitch,
                        180.0F,
                        (float) this.smoothing.getValue() / 100.0F
                );

                float yaw = Math.min(Math.abs(this.hSpeed.getValue()), 10.0F);
                float pitch = Math.min(Math.abs(this.vSpeed.getValue()), 10.0F);
                float currentYaw = mc.thePlayer.rotationYaw;
                float yawDelta = MathHelper.wrapAngleTo180_float(rotation[0] - currentYaw);
                float targetYaw = currentYaw + yawDelta * 0.1F * yaw;
                float currentPitch = mc.thePlayer.rotationPitch;
                float targetPitch = currentPitch + (rotation[1] - currentPitch) * 0.1F * pitch;
                Myau.rotationManager.setRotation(targetYaw, targetPitch, 0, false);
            }
        }
    }

    @Override
    public void onDisabled() {
        resetCombo();
        resetBlockFocus();
        lastPlayerHurtTime = 0;
        lastCombatAttackAt = 0L;
        this.timer.reset();
    }

    @EventTarget
    public void onPress(KeyEvent event) {
        if (event.getKey() == mc.gameSettings.keyBindAttack.getKeyCode()) {
            this.timer.reset();
        }
    }
}
