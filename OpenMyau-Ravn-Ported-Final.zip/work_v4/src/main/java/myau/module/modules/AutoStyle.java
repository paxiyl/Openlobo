package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.Render2DEvent;
import myau.events.UpdateEvent;
import myau.module.Module;
import myau.module.modules.autostyle.FlickEngine;
import myau.module.modules.autostyle.MovementAnalyzer;
import myau.module.modules.autostyle.Rotation;
import myau.module.modules.autostyle.TargetManager;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class AutoStyle extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final TargetManager targetMgr = new TargetManager();
    private static final FlickEngine flick = new FlickEngine();

    public final ModeProperty style = new ModeProperty("style", 0,
            new String[]{"AUTO", "SIDEWAYS", "LOOK-DOWN", "LOOK-UP", "DIAGONAL", "CLEAN"});
    public final FloatProperty range = new FloatProperty("range", 4.0F, 2.0F, 8.0F);
    public final IntProperty intensity = new IntProperty("intensity", 60, 0, 100);
    public final FloatProperty pitchAmt = new FloatProperty("pitch-amount", 7.0F, 0.0F, 20.0F);
    public final IntProperty cooldownMs = new IntProperty("cooldown-ms", 280, 40, 800);
    public final IntProperty minCombo = new IntProperty("min-combo", 3, 1, 10);
    public final BooleanProperty hitOnly = new BooleanProperty("hit-only", true);
    public final BooleanProperty manualTrigger = new BooleanProperty("manual-trigger", false);
    public final BooleanProperty movementOnly = new BooleanProperty("movement-only", true);
    public final BooleanProperty combo360 = new BooleanProperty("combo-360", true);
    public final IntProperty combo360Min = new IntProperty("360-min-combo", 3, 2, 10);
    public final BooleanProperty returnExact = new BooleanProperty("return-exact", true);

    private long lastFlickEnd = 0L;
    private int comboHits = 0;
    private int previousPlayerHurtTime = 0;
    private EntityPlayer lastTarget;

    public AutoStyle() {
        super("AutoStyle", false);
    }

    @Override
    public void onEnabled() {
        resetState();
    }

    @Override
    public void onDisabled() {
        resetState();
    }

    private void resetState() {
        targetMgr.reset();
        flick.reset();
        lastFlickEnd = 0L;
        previousPlayerHurtTime = 0;
        comboHits = 0;
        lastTarget = null;
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || event == null || event.isCancelled()
                || mc.thePlayer == null || mc.theWorld == null) return;
        if (!(event.getTarget() instanceof EntityPlayer)) return;
        if (movementOnly.getValue() && !MovementAnalyzer.isPlayerMoving()) return;

        EntityPlayer target = (EntityPlayer) event.getTarget();
        if (!isValidTarget(target)) return;

        if (target != lastTarget) {
            comboHits = 0;
            targetMgr.reset();
            lastTarget = target;
        }

        targetMgr.lockTarget(target);
        comboHits++;

        if (combo360.getValue() && comboHits >= combo360Min.getValue()) {
            if (flick.isFlicking()) {
                flick.queue360();
            } else {
                startFlick(target, true);
            }
            return;
        }

        if (comboHits >= minCombo.getValue() && !flick.isFlicking()) {
            startFlick(target, false);
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE
                || mc.thePlayer == null || mc.theWorld == null) return;

        if (mc.currentScreen != null) {
            flick.reset();
            return;
        }

        // A fresh local hit immediately cancels the current style chain.
        if (mc.thePlayer.hurtTime > 0 && previousPlayerHurtTime <= 0) {
            comboHits = 0;
            targetMgr.reset();
            lastTarget = null;
            flick.reset();
        }
        previousPlayerHurtTime = mc.thePlayer.hurtTime;

        if (movementOnly.getValue() && !MovementAnalyzer.isPlayerMoving()) {
            flick.reset();
            return;
        }

        EntityPlayer target = targetMgr.getLockedTarget();
        if (target != null && !isValidTarget(target)) {
            targetMgr.reset();
            lastTarget = null;
            comboHits = 0;
            flick.reset();
            target = null;
        }

        // When hit-only is disabled, AutoStyle can acquire a valid moving target
        // and start a normal style without waiting for AttackEvent. The default
        // remains hit-only, so this does not alter the normal combo-driven mode.
        if (!hitOnly.getValue() && target == null && !flick.isFlicking()) {
            EntityPlayer automaticTarget = findTarget();
            if (automaticTarget != null) {
                targetMgr.lockTarget(automaticTarget);
                lastTarget = automaticTarget;
                startFlick(automaticTarget, false);
            }
        }

        if (manualTrigger.getValue()) {
            manualTrigger.setValue(false);
            EntityPlayer manualTarget = target != null ? target : findTarget();
            if (manualTarget != null) {
                targetMgr.lockTarget(manualTarget);
                lastTarget = manualTarget;
                comboHits = Math.max(minCombo.getValue(), combo360Min.getValue());
                startFlick(manualTarget, combo360.getValue());
            }
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!isEnabled() || mc.thePlayer == null || mc.theWorld == null) return;

        if (mc.currentScreen != null || (movementOnly.getValue() && !MovementAnalyzer.isPlayerMoving())) {
            flick.reset();
            return;
        }

        if (!flick.isFlicking()) return;

        Rotation rot = flick.evaluate();
        if (rot == null) return;

        // Apply only the trajectory that was explicitly generated by AutoStyle.
        // FlickEngine already keeps the yaw on a continuous path and returns
        // exactly to the captured starting rotation.
        mc.thePlayer.rotationYaw = rot.yaw;
        mc.thePlayer.rotationPitch = rot.pitch;
        mc.thePlayer.rotationYawHead = rot.yaw;
        mc.thePlayer.renderYawOffset = rot.yaw;
    }

    private void startFlick(EntityPlayer target, boolean spin) {
        if (target == null || !MovementAnalyzer.isPlayerMoving()) return;

        long now = System.nanoTime();
        if (now < lastFlickEnd) return;

        flick.startFlick(
                target,
                intensity.getValue(),
                pitchAmt.getValue(),
                style.getValue(),
                spin,
                returnExact.getValue()
        );

        long duration = flick.getTrajectoryDurationNanos();
        if (duration > 0L) {
            lastFlickEnd = now + duration + cooldownMs.getValue() * 1_000_000L;
        }
    }

    private boolean isValidTarget(EntityPlayer target) {
        return target != null
                && target != mc.thePlayer
                && !target.isDead
                && target.isEntityAlive()
                && mc.thePlayer.getDistanceToEntity(target) <= range.getValue();
    }

    private EntityPlayer findTarget() {
        return targetMgr.findTarget(
                range.getValue(), 180.0, true, false,
                TargetManager.TargetPriority.COMBO_LOCK
        );
    }

    public static TargetManager getTargetManager() {
        return targetMgr;
    }

    public static FlickEngine getFlickEngine() {
        return flick;
    }
}
