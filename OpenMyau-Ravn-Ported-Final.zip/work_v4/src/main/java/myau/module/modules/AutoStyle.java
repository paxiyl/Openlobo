package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.UpdateEvent;
import myau.module.Module;
import myau.module.modules.autostyle.FlickEngine;
import myau.module.modules.autostyle.Rotation;
import myau.module.modules.autostyle.TargetManager;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class AutoStyle extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final TargetManager targetMgr = new TargetManager();
    private static final FlickEngine flick = new FlickEngine();

    public final ModeProperty style = new ModeProperty("style", 5,
            new String[]{"SUBTLE","CLEAN","NORMAL","AGGRESSIVE","BOXING","REFERENCE","CUSTOM"});
    public final FloatProperty range = new FloatProperty("range", 4.0F, 2.0F, 8.0F);
    public final IntProperty intensity = new IntProperty("intensity", 75, 0, 100);
    public final FloatProperty pitchAmt = new FloatProperty("pitch-amount", 8.0F, 0.0F, 25.0F);
    public final IntProperty cooldownMs = new IntProperty("cooldown-ms", 300, 100, 800);
    public final IntProperty minCombo = new IntProperty("min-combo", 3, 1, 10);
    public final BooleanProperty hitOnly = new BooleanProperty("hit-only", true);
    public final BooleanProperty manualTrigger = new BooleanProperty("manual-trigger", false);
    public final BooleanProperty debug = new BooleanProperty("debug", false);

    private long lastFlickEnd;
    private int prevEnemyHurtTime = -1;
    private int prevPlayerHurtTime;
    private int comboHits;
    private EntityPlayer lastTarget;
    private int lastStyle = -1;

    public AutoStyle() {
        super("AutoStyle", false);
    }

    @Override public void onEnabled() {
        targetMgr.reset(); flick.reset();
        lastFlickEnd = 0; prevEnemyHurtTime = -1; prevPlayerHurtTime = 0;
        comboHits = 0; lastTarget = null; lastStyle = -1;
        applyPreset();
    }

    @Override public void onDisabled() {
        targetMgr.reset(); flick.reset();
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || mc.thePlayer == null) return;
        if (!(event.getTarget() instanceof EntityPlayer)) return;
        EntityPlayer hit = (EntityPlayer) event.getTarget();
        if (hit != lastTarget) {
            comboHits = 0; prevEnemyHurtTime = -1; lastTarget = hit;
        }
        targetMgr.lockTarget(hit);
        long now = System.nanoTime();
        boolean canFlick = now - lastFlickEnd > cooldownMs.getValue() * 1_000_000L;
        boolean actualHit = hit.hurtTime > 0 && prevEnemyHurtTime <= 0;
        if (actualHit) {
            comboHits++;
            prevEnemyHurtTime = hit.hurtTime;
            if (canFlick && !flick.isFlicking() && comboHits >= minCombo.getValue()) {
                flick.startFlick(hit, intensity.getValue(), pitchAmt.getValue());
                lastFlickEnd = now + flick.getTrajectoryDurationNanos();
            }
        } else {
            prevEnemyHurtTime = hit.hurtTime;
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent e) {
        if (!isEnabled() || e.getType() != EventType.PRE || mc.thePlayer == null || mc.theWorld == null) return;
        if (mc.currentScreen != null) { flick.reset(); return; }
        if (lastStyle != style.getValue()) { applyPreset(); lastStyle = style.getValue(); }
        if (mc.thePlayer.hurtTime > 0 && prevPlayerHurtTime <= 0) { comboHits = 0; flick.reset(); }
        prevPlayerHurtTime = mc.thePlayer.hurtTime;
        if (manualTrigger.getValue()) {
            manualTrigger.setValue(false);
            EntityPlayer t = targetMgr.getLockedTarget();
            if (t == null) t = findTarget();
            if (t != null && !flick.isFlicking()) {
                targetMgr.lockTarget(t); lastTarget = t; comboHits = minCombo.getValue();
                flick.startFlick(t, intensity.getValue(), pitchAmt.getValue());
                lastFlickEnd = System.nanoTime() + flick.getTrajectoryDurationNanos();
            }
        }
        if (flick.isFlicking()) {
            Rotation rot = flick.evaluate();
            if (rot != null) {
                mc.thePlayer.rotationYaw = rot.yaw;
                mc.thePlayer.rotationPitch = rot.pitch;
                mc.thePlayer.rotationYawHead = rot.yaw;
                mc.thePlayer.renderYawOffset = rot.yaw;
            }
        }
    }

    private void applyPreset() {
        switch (style.getValue()) {
            case 0: intensity.setValue(25); pitchAmt.setValue(3F); cooldownMs.setValue(400); hitOnly.setValue(true); break;
            case 1: intensity.setValue(45); pitchAmt.setValue(5F); cooldownMs.setValue(350); hitOnly.setValue(true); break;
            case 2: intensity.setValue(60); pitchAmt.setValue(7F); cooldownMs.setValue(300); hitOnly.setValue(true); break;
            case 3: intensity.setValue(80); pitchAmt.setValue(10F); cooldownMs.setValue(220); hitOnly.setValue(true); break;
            case 4: intensity.setValue(90); pitchAmt.setValue(8F); cooldownMs.setValue(180); hitOnly.setValue(false); break;
            case 5: intensity.setValue(75); pitchAmt.setValue(8F); cooldownMs.setValue(280); hitOnly.setValue(true); break;
            default: break;
        }
    }

    private EntityPlayer findTarget() {
        return targetMgr.findTarget(range.getValue(), 180.0, true, false, TargetManager.TargetPriority.COMBO_LOCK);
    }

    public static TargetManager getTargetManager() { return targetMgr; }
    public static FlickEngine getFlickEngine() { return flick; }
}
