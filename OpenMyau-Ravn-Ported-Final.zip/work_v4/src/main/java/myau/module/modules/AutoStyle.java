package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.UpdateEvent;
import myau.module.Module;
import myau.module.modules.autostyle.FlickEngine;
import myau.module.modules.autostyle.MovementAnalyzer;
import myau.module.modules.autostyle.Rotation;
import myau.module.modules.autostyle.TargetManager;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class AutoStyle extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final TargetManager targetMgr = new TargetManager();
    private static final FlickEngine flick = new FlickEngine();

    public final ModeProperty style = new ModeProperty("style", 5,
            new String[]{"SUBTLE","CLEAN","NORMAL","AGGRESSIVE","BOXING","REFERENCE","CUSTOM"});
    public final FloatProperty range = new FloatProperty("range", 4.0F, 2.0F, 8.0F);
    public final IntProperty intensity = new IntProperty("intensity", 75, 0, 100);
    public final FloatProperty pitchAmt = new FloatProperty("pitch-amount", 8.0F, 0.0F, 25.0F);
    public final IntProperty cooldownMs = new IntProperty("cooldown-ms", 300, 100, 800);
    public final IntProperty minCombo = new IntProperty("min-combo", 3, 1, 10);
    public final BooleanProperty hitOnly = new BooleanProperty("hit-only", true);
    public final BooleanProperty manualTrigger = new BooleanProperty("manual-trigger", false);
    public final BooleanProperty debug = new BooleanProperty("debug", false);
    public final ModeProperty flickDirection = new ModeProperty("flick-direction", 0,
            new String[]{"AUTO","SIDEWAYS","LOOK-DOWN","LOOK-UP","DIAGONAL","CLEAN"});
    public final BooleanProperty combo360 = new BooleanProperty("combo-360", true);
    public final BooleanProperty movementOnly = new BooleanProperty("movement-only", true);
    public final IntProperty combo360Min = new IntProperty("360-min-combo", 3, 2, 10);

    private long lastFlickEnd;
    private int prevEnemyHurtTime = -1;
    private int prevPlayerHurtTime;
    private int comboHits;
    private EntityPlayer lastTarget;
    private EntityPlayer pending360Target;
    private boolean pending360;

    public AutoStyle() {
        super("AutoStyle", false);
    }

    @Override public void onEnabled() {
        targetMgr.reset();
        flick.reset();
        lastFlickEnd = 0L;
        prevEnemyHurtTime = -1;
        prevPlayerHurtTime = 0;
        comboHits = 0;
        lastTarget = null;
        pending360Target = null;
        pending360 = false;
    }

    @Override public void onDisabled() {
        targetMgr.reset();
        flick.reset();
        pending360Target = null;
        pending360 = false;
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || mc.thePlayer == null || mc.theWorld == null) return;
        if (!(event.getTarget() instanceof EntityPlayer)) return;
        if (movementOnly.getValue() && !MovementAnalyzer.isPlayerMoving()) return;

        EntityPlayer hit = (EntityPlayer) event.getTarget();
        if (hit != lastTarget) {
            comboHits = 0;
            prevEnemyHurtTime = -1;
            lastTarget = hit;
            pending360Target = null;
            pending360 = false;
        }

        targetMgr.lockTarget(hit);
        long now = System.nanoTime();
        boolean canFlick = now - lastFlickEnd > cooldownMs.getValue() * 1_000_000L;
        boolean actualHit = hit.hurtTime > 0 && prevEnemyHurtTime <= 0;

        if (!actualHit) {
            prevEnemyHurtTime = hit.hurtTime;
            return;
        }

        comboHits++;
        prevEnemyHurtTime = hit.hurtTime;

        if (!canFlick) return;

        if (combo360.getValue() && comboHits >= combo360Min.getValue()) {
            if (flick.isFlicking()) {
                // Queue the opposite spin so the chain continues immediately after the current trajectory.
                pending360Target = hit;
                pending360 = true;
            } else {
                startFlick(hit, true);
            }
            return;
        }

        if (!flick.isFlicking() && comboHits >= minCombo.getValue()) {
            startFlick(hit, false);
        }
    }

    private void startFlick(EntityPlayer target, boolean spin) {
        if (target == null || !MovementAnalyzer.isPlayerMoving()) return;
        flick.startFlick(target, intensity.getValue(), pitchAmt.getValue(), flickDirection.getValue(), spin);
        lastFlickEnd = System.nanoTime() + flick.getTrajectoryDurationNanos();
    }

    @EventTarget
    public void onUpdate(UpdateEvent e) {
        if (!isEnabled() || e.getType() != EventType.PRE || mc.thePlayer == null || mc.theWorld == null) return;
        if (mc.currentScreen != null) {
            flick.reset();
            pending360 = false;
            pending360Target = null;
            return;
        }

        // Styling is deliberately movement-only. Stopping movement cancels an active flick cleanly.
        if (movementOnly.getValue() && !MovementAnalyzer.isPlayerMoving()) {
            flick.reset();
            pending360 = false;
            pending360Target = null;
            return;
        }

        if (mc.thePlayer.hurtTime > 0 && prevPlayerHurtTime <= 0) {
            comboHits = 0;
            flick.reset();
            pending360 = false;
            pending360Target = null;
        }
        prevPlayerHurtTime = mc.thePlayer.hurtTime;

        if (manualTrigger.getValue()) {
            manualTrigger.setValue(false);
            EntityPlayer t = targetMgr.getLockedTarget();
            if (t == null) t = findTarget();
            if (t != null && !flick.isFlicking()) {
                targetMgr.lockTarget(t);
                lastTarget = t;
                comboHits = Math.max(minCombo.getValue(), combo360Min.getValue());
                startFlick(t, combo360.getValue());
            }
        }

        if (flick.isFlicking()) {
            Rotation rot = flick.evaluate();
            if (rot != null) {
                mc.thePlayer.rotationYaw = rot.yaw;
                mc.thePlayer.rotationPitch = rot.pitch;
                mc.thePlayer.rotationYawHead = rot.yaw;
                mc.thePlayer.renderYawOffset = rot.yaw;
            }
            return;
        }

        // Continue a queued 360 using FlickEngine's alternating direction state.
        if (pending360 && pending360Target != null) {
            EntityPlayer chained = pending360Target;
            pending360Target = null;
            pending360 = false;
            startFlick(chained, true);
        }
    }

    private void applyPreset() {
        switch (style.getValue()) {
            case 0: intensity.setValue(25); pitchAmt.setValue(3F); cooldownMs.setValue(400); hitOnly.setValue(true); break;
            case 1: intensity.setValue(45); pitchAmt.setValue(5F); cooldownMs.setValue(350); hitOnly.setValue(true); break;
            case 2: intensity.setValue(60); pitchAmt.setValue(7F); cooldownMs.setValue(300); hitOnly.setValue(true); break;
            case 3: intensity.setValue(80); pitchAmt.setValue(10F); cooldownMs.setValue(220); hitOnly.setValue(true); break;
            case 4: intensity.setValue(90); pitchAmt.setValue(8F); cooldownMs.setValue(180); hitOnly.setValue(false); break;
            case 5: intensity.setValue(75); pitchAmt.setValue(8F); cooldownMs.setValue(280); hitOnly.setValue(true); break;
            default: break;
        }
    }

    private EntityPlayer findTarget() {
        return targetMgr.findTarget(range.getValue(), 180.0, true, false, TargetManager.TargetPriority.COMBO_LOCK);
    }

    public static TargetManager getTargetManager() { return targetMgr; }
    public static FlickEngine getFlickEngine() { return flick; }
}
