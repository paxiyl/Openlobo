package myau.module.modules;

import myau.event.EventTarget;
import myau.event.Priority;
import myau.event.types.EventType;
import myau.events.UpdateEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.ItemUtil;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * BPGOD - Block Placement Guidance / God.
 *
 * Step 1: three-pillar assist.
 *
 * This module does NOT place blocks automatically. It only supplies a smooth
 * rotation toward a valid face that can be used to place the third block of
 * a two-block vertical pillar.
 */
public class BPGOD extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final BooleanProperty threePillar = new BooleanProperty("three-pillar", true);
    public final FloatProperty range = new FloatProperty("range", 3.2F, 2.0F, 5.0F);
    public final FloatProperty speed = new FloatProperty("speed", 14.0F, 1.0F, 30.0F);
    public final IntProperty strength = new IntProperty("strength", 100, 0, 100);
    public final BooleanProperty jumpingOnly = new BooleanProperty("jumping-only", true);
    public final BooleanProperty requireBlock = new BooleanProperty("require-block", true);

    private PlacementTarget activeTarget;
    private long lastTargetTime;

    public BPGOD() {
        super("BPGOD", false);
    }

    @Override
    public void onDisabled() {
        activeTarget = null;
        lastTargetTime = 0L;
    }

    @EventTarget(Priority.HIGH)
    public void onUpdate(UpdateEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE) {
            return;
        }
        if (mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) {
            activeTarget = null;
            return;
        }
        if (!threePillar.getValue()) {
            activeTarget = null;
            return;
        }

        if (requireBlock.getValue() && !isHoldingPlaceableBlock()) {
            activeTarget = null;
            return;
        }

        if (jumpingOnly.getValue() && !isInPillarPlacementMotion(mc.thePlayer)) {
            activeTarget = null;
            return;
        }

        PlacementTarget target = findBestThreePillarTarget();
        if (target == null) {
            activeTarget = null;
            return;
        }

        activeTarget = target;
        lastTargetTime = System.currentTimeMillis();

        applySmoothRotation(event, target.hitVec);
    }

    /**
     * Finds the nearest useful two-high column. The player's current position
     * is used instead of relying on a particular sequence of clicks, so it
     * works whether the jump happened before or after the second block.
     */
    private PlacementTarget findBestThreePillarTarget() {
        EntityPlayerSP player = mc.thePlayer;

        int minX = MathHelper.floor_double(player.posX - range.getValue());
        int maxX = MathHelper.floor_double(player.posX + range.getValue());
        int minZ = MathHelper.floor_double(player.posZ - range.getValue());
        int maxZ = MathHelper.floor_double(player.posZ + range.getValue());

        List<PlacementTarget> candidates = new ArrayList<>();

        // Search around the player's feet across a small vertical band. This
        // covers jumping beside the column and stepping onto its top block.
        int feetY = MathHelper.floor_double(player.getEntityBoundingBox().minY);
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = feetY - 1; y <= feetY + 2; y++) {
                    BlockPos base = new BlockPos(x, y, z);
                    BlockPos second = base.up();
                    BlockPos third = second.up();

                    if (!isSolid(base) || !isSolid(second) || !mc.theWorld.isAirBlock(third)) {
                        continue;
                    }

                    // Do not guide toward a distant/irrelevant pillar.
                    double horizontal = Math.sqrt(
                            square((x + 0.5D) - player.posX)
                                    + square((z + 0.5D) - player.posZ)
                    );
                    double vertical = Math.abs((y + 2.0D) - player.posY);
                    if (horizontal > range.getValue() || vertical > 3.0D) {
                        continue;
                    }

                    PlacementTarget target = chooseBestFace(third);
                    if (target == null) {
                        continue;
                    }

                    target.base = base;
                    target.horizontalDistance = horizontal;
                    target.verticalDistance = vertical;
                    candidates.add(target);
                }
            }
        }

        return candidates.stream()
                .min(Comparator.comparingDouble(this::scoreTarget))
                .orElse(null);
    }

    /**
     * Prefer a neighboring support block when it produces a better/simpler
     * angle. Otherwise use the top face of the second pillar block.
     */
    private PlacementTarget chooseBestFace(BlockPos third) {
        List<PlacementTarget> sideTargets = new ArrayList<>();

        EnumFacing[] sides = {
                EnumFacing.NORTH, EnumFacing.SOUTH,
                EnumFacing.WEST, EnumFacing.EAST
        };

        for (EnumFacing side : sides) {
            BlockPos support = third.offset(side);
            if (!isSolid(support)) {
                continue;
            }

            // We need the face of the support block that looks INTO the empty
            // third-block position.
            EnumFacing face = side.getOpposite();
            double x = support.getX() + 0.5D + face.getFrontOffsetX() * 0.499D;
            double y = support.getY() + 0.5D;
            double z = support.getZ() + 0.5D + face.getFrontOffsetZ() * 0.499D;

            Vec3 hit = new Vec3(x, y, z);
            if (isReachable(hit)) {
                sideTargets.add(new PlacementTarget(third, support, face, hit, false));
            }
        }

        if (!sideTargets.isEmpty()) {
            sideTargets.sort(Comparator.comparingDouble(this::rotationCost));
            PlacementTarget bestSide = sideTargets.get(0);

            // Only select a side support when it is meaningfully better than
            // the top. This keeps the module from making unnecessary lateral
            // camera movements.
            PlacementTarget top = topFaceTarget(third);
            if (top == null || rotationCost(bestSide) + 1.5D < rotationCost(top)) {
                return bestSide;
            }
        }

        return topFaceTarget(third);
    }

    private PlacementTarget topFaceTarget(BlockPos third) {
        BlockPos support = third.down();
        if (!isSolid(support)) {
            return null;
        }

        Vec3 hit = new Vec3(
                support.getX() + 0.5D,
                support.getY() + 0.999D,
                support.getZ() + 0.5D
        );

        return isReachable(hit)
                ? new PlacementTarget(third, support, EnumFacing.UP, hit, true)
                : null;
    }

    private void applySmoothRotation(UpdateEvent event, Vec3 hitVec) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);

        double dx = hitVec.xCoord - eyes.xCoord;
        double dy = hitVec.yCoord - eyes.yCoord;
        double dz = hitVec.zCoord - eyes.zCoord;

        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));

        targetYaw = MathHelper.wrapAngleTo180_float(targetYaw);
        targetPitch = MathHelper.clamp_float(targetPitch, -90.0F, 90.0F);

        float currentYaw = event.getYaw();
        float currentPitch = event.getPitch();

        float yawDelta = MathHelper.wrapAngleTo180_float(targetYaw - currentYaw);
        float pitchDelta = targetPitch - currentPitch;

        float strengthScale = strength.getValue() / 100.0F;
        float maxStep = speed.getValue() * strengthScale;

        // Ease the final few degrees so the module settles onto the exact
        // placement face instead of stopping short or snapping into it.
        float yawStep = easedStep(yawDelta, maxStep);
        float pitchStep = easedStep(pitchDelta, maxStep);

        float nextYaw = currentYaw + yawStep;
        float nextPitch = MathHelper.clamp_float(currentPitch + pitchStep, -90.0F, 90.0F);

        event.setRotation(nextYaw, nextPitch, 6);
        event.setPervRotation(nextYaw, 6);
    }

    private float easedStep(float delta, float maxStep) {
        float abs = Math.abs(delta);
        if (abs <= 0.35F) {
            return delta;
        }

        float step = Math.min(abs, maxStep);
        if (abs < maxStep * 1.5F) {
            step = Math.min(abs, maxStep * 0.72F + abs * 0.28F);
        }

        return Math.copySign(step, delta);
    }

    private boolean isInPillarPlacementMotion(EntityPlayerSP player) {
        boolean jumpKey = mc.gameSettings.keyBindJump != null
                && mc.gameSettings.keyBindJump.isKeyDown();

        // Covers the actual jump phase and the short rising/falling transition
        // after the second block is placed.
        boolean airborne = !player.onGround;
        boolean upwardMotion = player.motionY > -0.32D && player.motionY < 0.52D;

        return jumpKey || (airborne && upwardMotion);
    }

    private boolean isHoldingPlaceableBlock() {
        ItemStack stack = mc.thePlayer.getHeldItem();
        return stack != null && stack.getItem() instanceof ItemBlock;
    }

    private boolean isSolid(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        Material material = block.getMaterial();
        return block.isCollidable()
                && material != null
                && material.blocksMovement()
                && !mc.theWorld.isAirBlock(pos);
    }

    private boolean isReachable(Vec3 point) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        double dx = point.xCoord - eyes.xCoord;
        double dy = point.yCoord - eyes.yCoord;
        double dz = point.zCoord - eyes.zCoord;
        return Math.sqrt(dx * dx + dy * dy + dz * dz) <= range.getValue();
    }

    private double rotationCost(PlacementTarget target) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);

        double dx = target.hitVec.xCoord - eyes.xCoord;
        double dy = target.hitVec.yCoord - eyes.yCoord;
        double dz = target.hitVec.zCoord - eyes.zCoord;

        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));

        float yawDelta = Math.abs(MathHelper.wrapAngleTo180_float(yaw - mc.thePlayer.rotationYaw));
        float pitchDelta = Math.abs(pitch - mc.thePlayer.rotationPitch);

        return yawDelta + pitchDelta * 0.70D + eyes.distanceTo(target.hitVec) * 0.25D;
    }

    private double scoreTarget(PlacementTarget target) {
        double motionPenalty = mc.thePlayer.motionY < 0.0D ? 0.25D : 0.0D;
        return rotationCost(target)
                + target.horizontalDistance * 1.25D
                + target.verticalDistance * 0.35D
                + motionPenalty;
    }

    private double square(double value) {
        return value * value;
    }

    private static final class PlacementTarget {
        private final BlockPos third;
        private final BlockPos support;
        private final EnumFacing facing;
        private final Vec3 hitVec;
        private final boolean topFace;

        private BlockPos base;
        private double horizontalDistance;
        private double verticalDistance;

        private PlacementTarget(
                BlockPos third,
                BlockPos support,
                EnumFacing facing,
                Vec3 hitVec,
                boolean topFace
        ) {
            this.third = third;
            this.support = support;
            this.facing = facing;
            this.hitVec = hitVec;
            this.topFace = topFace;
        }
    }
}
