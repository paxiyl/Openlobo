package myau.module.modules.autostyle;

public class FlickTrajectory {

    public enum Style { NORMAL, SPIN }

    private final float startYaw, startPitch;
    private final float peakYaw, peakPitch;
    private final float endYaw, endPitch;
    private final long awayNanos;
    private final long holdNanos;
    private final long returnNanos;
    private final long totalNanos;
    private final Style style;

    public FlickTrajectory(
        float startYaw, float startPitch,
        float peakYaw, float peakPitch,
        float endYaw, float endPitch,
        long awayNanos, long holdNanos, long returnNanos,
        Style style
    ) {
        this.startYaw = startYaw;
        this.startPitch = startPitch;
        this.peakYaw = peakYaw;
        this.peakPitch = peakPitch;
        this.endYaw = endYaw;
        this.endPitch = endPitch;
        this.awayNanos = awayNanos;
        this.holdNanos = holdNanos;
        this.returnNanos = returnNanos;
        this.totalNanos = awayNanos + holdNanos + returnNanos;
        this.style = style;
    }

    public Rotation evaluate(long elapsedNanos) {
        if (elapsedNanos >= totalNanos) return new Rotation(endYaw, endPitch);

        if (elapsedNanos < awayNanos) {
            double t = (double) elapsedNanos / (double) awayNanos;
            // Quintic easing keeps acceleration/deceleration continuous and removes the visible snap.
            double e = easeInOutQuint(t);
            if (style == Style.SPIN) {
                // Maintain a near-constant middle section while remaining smooth at both ends.
                e = spinEase(t);
            }
            return interpolate(startYaw, startPitch, peakYaw, peakPitch, e);
        }

        long afterAway = elapsedNanos - awayNanos;
        if (afterAway < holdNanos) {
            return new Rotation(peakYaw, Rotation.clampPitch(peakPitch));
        }

        long afterHold = afterAway - holdNanos;
        double t = Math.min(1.0, (double) afterHold / (double) returnNanos);
        double e = easeInOutQuint(t);
        return interpolate(peakYaw, peakPitch, endYaw, endPitch, e);
    }

    private Rotation interpolate(float fromYaw, float fromPitch, float toYaw, float toPitch, double e) {
        float yaw = fromYaw + (toYaw - fromYaw) * (float) e;
        float pitch = Rotation.clampPitch(fromPitch + (toPitch - fromPitch) * (float) e);
        return new Rotation(yaw, pitch);
    }

    private static double easeInOutQuint(double t) {
        if (t <= 0.0) return 0.0;
        if (t >= 1.0) return 1.0;
        return t < 0.5
                ? 16.0 * t * t * t * t * t
                : 1.0 - Math.pow(-2.0 * t + 2.0, 5.0) / 2.0;
    }

    private static double spinEase(double t) {
        // Smooth acceleration and deceleration with a high-speed middle.
        if (t < 0.14) {
            double p = t / 0.14;
            return 0.10 * easeInOutQuint(p);
        }
        if (t > 0.86) {
            double p = (t - 0.86) / 0.14;
            return 0.90 + 0.10 * easeInOutQuint(p);
        }
        return 0.10 + (t - 0.14) * (0.80 / 0.72);
    }

    public boolean isComplete(long elapsedNanos) {
        return elapsedNanos >= totalNanos;
    }

    public long getTotalNanos() { return totalNanos; }
}
