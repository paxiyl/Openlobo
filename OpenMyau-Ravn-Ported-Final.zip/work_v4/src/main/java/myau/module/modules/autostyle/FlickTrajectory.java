package myau.module.modules.autostyle;

import net.minecraft.entity.player.EntityPlayer;

public class FlickTrajectory {
    public enum Style { NORMAL, SPIN }

    private final float startYaw, startPitch;
    private final float peakYaw, peakPitch;
    private final float endYaw, endPitch;
    private final long awayNanos, holdNanos, targetReturnNanos, finalReturnNanos, totalNanos;
    private final Style style;
    private final EntityPlayer dynamicTarget;

    public FlickTrajectory(float startYaw, float startPitch,
                           float peakYaw, float peakPitch,
                           float endYaw, float endPitch,
                           long awayNanos, long holdNanos, long returnNanos,
                           Style style) {
        this(startYaw, startPitch, peakYaw, peakPitch, endYaw, endPitch,
                awayNanos, holdNanos, 0L, returnNanos, style, null);
    }

    public FlickTrajectory(float startYaw, float startPitch,
                           float peakYaw, float peakPitch,
                           long awayNanos, long holdNanos,
                           long targetReturnNanos, long finalReturnNanos,
                           Style style, EntityPlayer dynamicTarget) {
        this(startYaw, startPitch, peakYaw, peakPitch, startYaw, startPitch,
                awayNanos, holdNanos, targetReturnNanos, finalReturnNanos,
                style, dynamicTarget);
    }

    private FlickTrajectory(float startYaw, float startPitch,
                            float peakYaw, float peakPitch,
                            float endYaw, float endPitch,
                            long awayNanos, long holdNanos,
                            long targetReturnNanos, long finalReturnNanos,
                            Style style, EntityPlayer dynamicTarget) {
        this.startYaw = startYaw;
        this.startPitch = startPitch;
        this.peakYaw = peakYaw;
        this.peakPitch = peakPitch;
        this.endYaw = endYaw;
        this.endPitch = endPitch;
        this.awayNanos = Math.max(1L, awayNanos);
        this.holdNanos = Math.max(0L, holdNanos);
        this.targetReturnNanos = Math.max(0L, targetReturnNanos);
        this.finalReturnNanos = Math.max(1L, finalReturnNanos);
        this.totalNanos = this.awayNanos + this.holdNanos + this.targetReturnNanos + this.finalReturnNanos;
        this.style = style;
        this.dynamicTarget = dynamicTarget;
    }

    public Rotation evaluate(long elapsedNanos) {
        return evaluate(elapsedNanos, endYaw, endPitch);
    }

    public Rotation evaluate(long elapsedNanos, float dynamicEndYaw, float dynamicEndPitch) {
        if (elapsedNanos <= 0L) return new Rotation(startYaw, startPitch);
        if (elapsedNanos >= totalNanos) return new Rotation(endYaw, endPitch);

        if (elapsedNanos < awayNanos) {
            double t = (double) elapsedNanos / (double) awayNanos;
            double e = style == Style.SPIN ? spinEase(t) : easeInOutQuint(t);
            return interpolate(startYaw, startPitch, peakYaw, peakPitch, e);
        }

        long afterAway = elapsedNanos - awayNanos;
        if (afterAway < holdNanos) {
            return new Rotation(peakYaw, Rotation.clampPitch(peakPitch));
        }

        long afterHold = afterAway - holdNanos;
        if (targetReturnNanos > 0L && afterHold < targetReturnNanos) {
            double t = (double) afterHold / (double) targetReturnNanos;
            double e = easeInOutQuint(t);
            return interpolate(peakYaw, peakPitch, dynamicEndYaw, dynamicEndPitch, e);
        }

        if (targetReturnNanos > 0L) {
            long finalElapsed = afterHold - targetReturnNanos;
            double t = Math.min(1.0D, (double) finalElapsed / (double) finalReturnNanos);
            double e = easeInOutQuint(t);
            return interpolate(dynamicEndYaw, dynamicEndPitch, endYaw, endPitch, e);
        }

        double t = Math.min(1.0D, (double) afterHold / (double) finalReturnNanos);
        double e = easeInOutQuint(t);
        return interpolate(peakYaw, peakPitch, endYaw, endPitch, e);
    }

    private Rotation interpolate(float fromYaw, float fromPitch,
                                 float toYaw, float toPitch, double e) {
        float yawDelta = Rotation.angleDiff(fromYaw, toYaw);
        float yaw = fromYaw + yawDelta * (float) e;
        float pitch = Rotation.clampPitch(fromPitch + (toPitch - fromPitch) * (float) e);
        return new Rotation(yaw, pitch);
    }

    private static double easeInOutQuint(double t) {
        if (t <= 0.0D) return 0.0D;
        if (t >= 1.0D) return 1.0D;
        return t < 0.5D
                ? 16.0D * t * t * t * t * t
                : 1.0D - Math.pow(-2.0D * t + 2.0D, 5.0D) / 2.0D;
    }

    private static double spinEase(double t) {
        if (t <= 0.0D) return 0.0D;
        if (t >= 1.0D) return 1.0D;
        if (t < 0.12D) {
            double p = t / 0.12D;
            return 0.08D * easeInOutQuint(p);
        }
        if (t > 0.88D) {
            double p = (t - 0.88D) / 0.12D;
            return 0.92D + 0.08D * easeInOutQuint(p);
        }
        return 0.08D + (t - 0.12D) * (0.84D / 0.76D);
    }

    public boolean isComplete(long elapsedNanos) {
        return elapsedNanos >= totalNanos;
    }

    public long getTotalNanos() {
        return totalNanos;
    }

    public EntityPlayer getDynamicTarget() {
        return dynamicTarget;
    }
}
