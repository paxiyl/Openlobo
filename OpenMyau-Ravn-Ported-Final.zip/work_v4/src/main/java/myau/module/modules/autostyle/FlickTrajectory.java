package myau.module.modules.autostyle;

public class FlickTrajectory {
    public enum Style { NORMAL, SPIN }

    private final float startYaw, startPitch;
    private final float peakYaw, peakPitch;
    private final float endYaw, endPitch;
    private final long awayNanos, holdNanos, returnNanos, totalNanos;
    private final Style style;

    public FlickTrajectory(float startYaw, float startPitch,
                           float peakYaw, float peakPitch,
                           float endYaw, float endPitch,
                           long awayNanos, long holdNanos, long returnNanos,
                           Style style) {
        this.startYaw = startYaw;
        this.startPitch = startPitch;
        this.peakYaw = peakYaw;
        this.peakPitch = peakPitch;
        this.endYaw = endYaw;
        this.endPitch = endPitch;
        this.awayNanos = awayNanos;
        this.holdNanos = holdNanos;
        this.returnNanos = returnNanos;
        this.totalNanos = awayNanos + holdNanos + returnNanos;
        this.style = style;
    }

    public Rotation evaluate(long elapsedNanos) {
        if (elapsedNanos <= 0L) return new Rotation(startYaw, startPitch);
        if (elapsedNanos >= totalNanos) return new Rotation(endYaw, endPitch);

        if (elapsedNanos < awayNanos) {
            double t = (double) elapsedNanos / (double) awayNanos;
            double e = style == Style.SPIN ? spinEase(t) : easeInOutQuint(t);
            return interpolate(startYaw, startPitch, peakYaw, peakPitch, e);
        }

        long afterAway = elapsedNanos - awayNanos;
        if (afterAway < holdNanos) {
            return new Rotation(peakYaw, Rotation.clampPitch(peakPitch));
        }

        long afterHold = afterAway - holdNanos;
        double t = Math.min(1.0D, (double) afterHold / (double) returnNanos);
        double e = easeInOutQuint(t);
        return interpolate(peakYaw, peakPitch, endYaw, endPitch, e);
    }

    private Rotation interpolate(float fromYaw, float fromPitch,
                                 float toYaw, float toPitch, double e) {
        float yaw = fromYaw + (toYaw - fromYaw) * (float) e;
        float pitch = Rotation.clampPitch(fromPitch + (toPitch - fromPitch) * (float) e);
        return new Rotation(yaw, pitch);
    }

    private static double easeInOutQuint(double t) {
        if (t <= 0.0D) return 0.0D;
        if (t >= 1.0D) return 1.0D;
        return t < 0.5D
                ? 16.0D * t * t * t * t * t
                : 1.0D - Math.pow(-2.0D * t + 2.0D, 5.0D) / 2.0D;
    }

    private static double spinEase(double t) {
        if (t <= 0.0D) return 0.0D;
        if (t >= 1.0D) return 1.0D;
        if (t < 0.12D) {
            double p = t / 0.12D;
            return 0.08D * easeInOutQuint(p);
        }
        if (t > 0.88D) {
            double p = (t - 0.88D) / 0.12D;
            return 0.92D + 0.08D * easeInOutQuint(p);
        }
        return 0.08D + (t - 0.12D) * (0.84D / 0.76D);
    }

    public boolean isComplete(long elapsedNanos) {
        return elapsedNanos >= totalNanos;
    }

    public long getTotalNanos() {
        return totalNanos;
    }
}
