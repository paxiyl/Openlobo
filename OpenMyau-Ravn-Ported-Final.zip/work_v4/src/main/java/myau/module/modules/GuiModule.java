package myau.module.modules;

import myau.event.EventTarget;
import myau.events.TickEvent;
import myau.module.Module;
import myau.ui.ClickGui;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiModule extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private ClickGui clickGui;
    private boolean keyWasDown;

    public GuiModule() {
        super("ClickGui", false);
        setKey(Keyboard.KEY_RSHIFT);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (getKey() <= 0) {
            keyWasDown = false;
            return;
        }

        boolean keyDown = Keyboard.isKeyDown(getKey());
        if (keyDown && !keyWasDown && mc.currentScreen == null) {
            openGui();
        }
        keyWasDown = keyDown;
    }

    @Override
    public void onEnabled() {
        openGui();
    }

    private void openGui() {
        if (clickGui == null) {
            clickGui = new ClickGui();
        }
        mc.displayGuiScreen(clickGui);
        if (isEnabled()) {
            enabled = false;
        }
    }
}
