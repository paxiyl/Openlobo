package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.module.Module;
import myau.ui.ClickGui;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiModule extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final int OPEN_KEY = Keyboard.KEY_RSHIFT;
    private ClickGui clickGui;
    private boolean wasOpenKeyDown;

    public GuiModule() {
        super("ClickGui", false);
        setKey(OPEN_KEY);
    }

    @Override
    public void onEnabled() {
        openGui();
        setEnabled(false);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) {
            return;
        }

        boolean down = Keyboard.isKeyDown(OPEN_KEY);
        if (down && !wasOpenKeyDown && mc.currentScreen == null) {
            openGui();
        }
        wasOpenKeyDown = down;
    }

    private void openGui() {
        if (clickGui == null) {
            clickGui = new ClickGui();
        }
        if (mc.currentScreen != clickGui) {
            mc.displayGuiScreen(clickGui);
        }
    }
}
