package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.module.Module;
import myau.ui.ClickGui;
import org.lwjgl.input.Keyboard;

public class GuiModule extends Module {
    private boolean keyDown;

    public GuiModule() {
        // This module is only the client GUI opener; it does not need to be
        // enabled in order for the hotkey to work.
        super("ClickGui", false);
        setKey(Keyboard.KEY_RSHIFT);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) {
            return;
        }

        boolean down = Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);

        // Open only on the press edge so holding RSHIFT cannot repeatedly
        // recreate the screen.
        if (down && !keyDown && mc.currentScreen == null) {
            mc.displayGuiScreen(new ClickGui());
        }

        keyDown = down;
    }

    @Override
    public void onEnabled() {
        // GUI opening is handled directly by onTick.
        setEnabled(false);
    }
}
